# -*- coding: utf-8 -*-
"""Translation engines. Pure Python (urllib only, no Kodi imports).

Every engine takes a list of lines and returns a list of the same length.
New engines are added by subclassing Engine and registering them in ENGINES."""
import json
import re
import socket
import time

try:  # Kodi 19+ (Python 3)
    from urllib.error import HTTPError, URLError
    from urllib.parse import urlencode
    from urllib.request import Request, urlopen
except ImportError:  # Kodi 17/18 (Python 2.7)
    from urllib import urlencode
    from urllib2 import HTTPError, Request, URLError, urlopen

try:
    import ssl
except ImportError:  # pragma: no cover
    ssl = None

PY2 = str is bytes

USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/124.0 Safari/537.36')

# Replaced by Kodi glue with an abort-aware wait (xbmc.Monitor().waitForAbort).
sleep = time.sleep
# Kodi's own CA bundle (special://xbmc/system/certs/cacert.pem), set by the Kodi glue.
# Used when the platform's Python can't verify HTTPS certificates by itself.
CA_FILE = None


class EngineError(Exception):
    """Network/auth/quota failure. Triggers the fallback engine.

    kind: 'auth' (key rejected), 'quota' (limit reached), 'not_found' (model or
    URL wrong), 'refused' (service not running), 'network', 'timeout',
    'server', 'mismatch' (unusable answer), 'file' (bad subtitle), 'other'."""

    def __init__(self, message, kind='other', status=None, detail=u''):
        Exception.__init__(self, message)
        self.kind = kind
        self.status = status
        self.detail = detail


class MismatchError(EngineError):
    """Engine answered, but not with one translation per line."""

    def __init__(self, message):
        EngineError.__init__(self, message, 'mismatch')


def classify_http(status, detail):
    text = (detail or u'').lower()
    if status in (401, 403) or 'api key not valid' in text or 'api_key_invalid' in text \
            or 'invalid api key' in text or 'invalid_api_key' in text or 'unauthorized' in text:
        return 'auth'
    if status in (429, 456) or 'quota' in text or 'rate limit' in text:
        return 'quota'  # 456 = DeepL's "quota exceeded"
    if status == 404 or (status == 400 and 'model' in text and (
            'not found' in text or 'does not exist' in text or 'decommissioned' in text)):
        return 'not_found'
    if status >= 500:
        return 'server'
    return 'other'


def classify_network(error):
    reason = getattr(error, 'reason', error)
    text = (u'%s' % (reason,)).lower() if not isinstance(reason, bytes) else repr(reason)
    if isinstance(reason, socket.timeout) or 'timed out' in text:
        return 'timeout'
    if isinstance(reason, socket.gaierror) or 'name or service not known' in text \
            or 'getaddrinfo' in text or 'nodename nor servname' in text:
        return 'network'
    if getattr(reason, 'errno', None) in (61, 111, 10061) or 'refused' in text:
        return 'refused'
    return 'network'


LANGUAGE_NAMES = {
    'auto': 'the original language', 'en': 'English', 'mk': 'Macedonian',
    'sr': 'Serbian', 'sr-latn': 'Serbian (Latin script)',
    'sr-cyrl': 'Serbian (Cyrillic script)', 'hr': 'Croatian', 'bs': 'Bosnian', 'sl': 'Slovenian',
    'bg': 'Bulgarian', 'sq': 'Albanian', 'el': 'Greek', 'tr': 'Turkish',
    'de': 'German', 'fr': 'French', 'es': 'Spanish', 'it': 'Italian',
    'pt': 'Portuguese', 'ro': 'Romanian', 'hu': 'Hungarian', 'pl': 'Polish',
    'cs': 'Czech', 'sk': 'Slovak', 'ru': 'Russian', 'uk': 'Ukrainian',
    'nl': 'Dutch', 'sv': 'Swedish', 'no': 'Norwegian', 'nb': 'Norwegian',
    'da': 'Danish', 'fi': 'Finnish', 'et': 'Estonian', 'lv': 'Latvian',
    'lt': 'Lithuanian', 'ar': 'Arabic', 'he': 'Hebrew', 'fa': 'Persian',
    'hi': 'Hindi', 'bn': 'Bengali', 'ur': 'Urdu', 'zh': 'Chinese',
    'ja': 'Japanese', 'ko': 'Korean', 'vi': 'Vietnamese', 'th': 'Thai',
    'id': 'Indonesian', 'ms': 'Malay', 'tl': 'Filipino',
}


def language_name(code):
    return LANGUAGE_NAMES.get((code or '').lower(), code)


def form_encode(params):
    """urlencode that also works with non-ASCII text on Python 2."""
    return urlencode(dict((k, v.encode('utf-8') if not isinstance(v, bytes) else v)
                          for k, v in params.items()))


# Modern TLS settings (what Python 3 uses). Python 2.7's defaults look like an
# old bot to Google and get "429 Sorry..."; with these they are accepted.
_CIPHERS = ('ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20:ECDH+AESGCM:'
            'DH+AESGCM:ECDH+AES:DH+AES:RSA+AESGCM:RSA+AES:!aNULL:!eNULL:!MD5:!DSS')
_contexts = {}


def _context(cafile=None):
    """None when this Python has no SSLContext (Python 2.7 < 2.7.9)."""
    if not (ssl and hasattr(ssl, 'create_default_context')):
        return None
    if cafile not in _contexts:
        context = ssl.create_default_context(cafile=cafile)
        try:
            context.set_ciphers(_CIPHERS)
        except ssl.SSLError:
            pass
        if hasattr(context, 'set_alpn_protocols'):
            try:
                context.set_alpn_protocols(['http/1.1'])
            except (NotImplementedError, ssl.SSLError):
                pass
        _contexts[cafile] = context
    return _contexts[cafile]


def _open(request, timeout):
    context = _context()
    if context is None:
        return urlopen(request, timeout=timeout)
    try:
        return urlopen(request, timeout=timeout, context=context)
    except URLError as error:
        if not (CA_FILE and isinstance(getattr(error, 'reason', None), ssl.SSLError)):
            raise
        # Certificate store missing (seen on some Android/Windows Kodi builds):
        # retry with the CA bundle that ships with Kodi.
        return urlopen(request, timeout=timeout, context=_context(CA_FILE))


def http_request(url, data=None, headers=None, timeout=60, retries=4):
    """POST (when data is given) or GET with retry on 429/5xx and network errors.
    `data` may be bytes or a dict/list (sent as JSON)."""
    all_headers = {'User-Agent': USER_AGENT}
    all_headers.update(headers or {})
    if data is not None and not isinstance(data, bytes):
        data = json.dumps(data).encode('utf-8')
        all_headers.setdefault('Content-Type', 'application/json')
    for attempt in range(retries + 1):
        try:
            response = _open(Request(url, data=data, headers=all_headers), timeout)
            try:
                return response.read().decode('utf-8')
            finally:
                response.close()
        except HTTPError as error:
            try:
                detail = error.read().decode('utf-8', 'replace')[:300]
            finally:
                try:
                    error.close()  # release the connection
                except Exception:  # pylint: disable=broad-except
                    pass
            if error.code in (429, 500, 502, 503, 504) and attempt < retries \
                    and not _is_daily_quota(detail):
                sleep(_retry_delay(error, attempt))
                continue
            raise EngineError(u'HTTP %d: %s' % (error.code, detail),
                              classify_http(error.code, detail), error.code, detail)
        except (URLError, IOError, OSError, socket.timeout) as error:
            kind = classify_network(error)
            # nothing listens there (e.g. Ollama not started): retrying won't help
            if attempt < retries and kind != 'refused':
                sleep(2 * (attempt + 1))
                continue
            raise EngineError(u'Network error: %s' % _describe(error), kind, None, _describe(error))
    raise EngineError('Gave up after %d attempts' % (retries + 1))


def _describe(error):
    reason = getattr(error, 'reason', error)
    try:
        return u'%s' % (reason,)
    except UnicodeDecodeError:  # Python 2 with a localized OS error message
        return repr(reason)


def _is_daily_quota(detail):
    # Per-day quotas won't reset by waiting a minute: fail fast -> fallback engine.
    text = detail.lower()
    return 'per day' in text or 'perday' in text or 'daily' in text


def _retry_delay(error, attempt):
    try:
        return min(65.0, float(error.info().get('Retry-After')))
    except (TypeError, ValueError):
        return min(65.0, 5.0 * (2 ** attempt))


def take_batch(lines, start, max_items, max_chars):
    batch, chars = [], 0
    for line in lines[start:]:
        if batch and (len(batch) >= max_items or chars + len(line) > max_chars):
            break
        batch.append(line)
        chars += len(line) + 1
    return batch


class Engine(object):
    key = 'base'
    name = 'Engine'
    contextual = False  # True = understands context, gets lines as-is (AI)
    max_items = 100
    max_chars = 4000

    def __init__(self, source='auto', target='en', **options):
        self.source = (source or 'auto').lower()
        self.target = target.lower()          # may carry a script: sr-latn
        self.api_source = self.source.split('-')[0]
        self.api_target = self.target.split('-')[0]
        self.options = options

    @property
    def signature(self):
        """Identifies the output quality for the cache key."""
        return self.key

    def translate(self, lines, context=None):
        raise NotImplementedError


class GoogleFree(Engine):
    """The free endpoint used by Google's own web widgets. No key, no fixed quota."""
    key = 'google'
    name = 'Google Translate'
    max_items = 80
    max_chars = 4000
    URL = 'https://translate.googleapis.com/translate_a/single'

    def translate(self, lines, context=None):
        query = form_encode({'client': 'gtx', 'sl': self.api_source, 'tl': self.api_target,
                             'dt': 't', 'ie': 'UTF-8', 'oe': 'UTF-8'})
        body = form_encode({'q': u'\n'.join(lines)})
        if not isinstance(body, bytes):
            body = body.encode('utf-8')
        raw = http_request(self.URL + '?' + query, body,
                           {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'})
        try:
            segments = json.loads(raw)[0] or []
        except (ValueError, IndexError, TypeError):
            raise MismatchError('Unexpected Google response')
        text = u''.join(seg[0] for seg in segments if seg and seg[0])
        return [line.strip() for line in text.split(u'\n')]


class DeepLFree(Engine):
    key = 'deepl'
    name = 'DeepL'
    max_items = 50
    max_chars = 20000
    TARGET_VARIANTS = {'en': 'EN-US', 'pt': 'PT-BR', 'zh': 'ZH-HANS', 'no': 'NB'}

    def translate(self, lines, context=None):
        api_key = self.options.get('api_key', '')
        host = 'api-free.deepl.com' if api_key.endswith(':fx') else 'api.deepl.com'
        payload = {'text': lines,
                   'target_lang': self.TARGET_VARIANTS.get(self.api_target,
                                                           self.api_target.upper())}
        if self.source != 'auto':
            payload['source_lang'] = self.api_source.upper()
        if context:
            payload['context'] = ' '.join(context)
        raw = http_request('https://%s/v2/translate' % host, payload,
                           {'Authorization': 'DeepL-Auth-Key ' + api_key})
        try:
            return [item['text'] for item in json.loads(raw)['translations']]
        except (ValueError, KeyError, TypeError):
            raise MismatchError('Unexpected DeepL response')


class LibreTranslate(Engine):
    key = 'libre'
    name = 'LibreTranslate'
    max_items = 50
    max_chars = 8000

    def translate(self, lines, context=None):
        payload = {'q': lines, 'source': self.api_source, 'target': self.api_target,
                   'format': 'text'}
        if self.options.get('api_key'):
            payload['api_key'] = self.options['api_key']
        url = self.options.get('url', 'http://localhost:5000').rstrip('/') + '/translate'
        try:
            result = json.loads(http_request(url, payload))['translatedText']
        except (ValueError, KeyError, TypeError):
            raise MismatchError('Unexpected LibreTranslate response')
        return result if isinstance(result, list) else [result]


AI_PROMPT = u"""You translate movie and TV subtitles from {source} into {target}.
The user sends JSON: "lines" are subtitle lines in playback order; "context_before" are earlier lines, for context only (do not translate them).
Rules:
- Reply with ONLY a JSON array of exactly {count} strings. Item i is the {target} text for lines[i].
- Translate the meaning, not word by word. Write natural, spoken {target}, short like real subtitles.
- A sentence often continues over several lines: translate it as a whole, then spread it over those same lines in natural {target} word order.
- Keep names. Keep formal/informal address consistent and use the correct grammatical gender for speakers.
- Keep slang, idioms and jokes as natural {target} equivalents.
- Never merge, drop, add, explain or comment on lines."""


class OpenAICompatible(Engine):
    """Any /chat/completions API: Gemini, Groq, OpenRouter, Ollama, LM Studio..."""
    key = 'ai'
    name = 'AI'
    contextual = True
    max_chars = 12000
    PRESETS = {
        'gemini': ('Gemini', 'https://generativelanguage.googleapis.com/v1beta/openai',
                   'gemini-flash-lite-latest'),
        'groq': ('Groq', 'https://api.groq.com/openai/v1', 'llama-3.3-70b-versatile'),
        'openrouter': ('OpenRouter', 'https://openrouter.ai/api/v1',
                       'meta-llama/llama-3.3-70b-instruct:free'),
        'ollama': ('Ollama', 'http://localhost:11434/v1', 'llama3.1'),
        'custom': ('AI', 'http://localhost:1234/v1', ''),
    }

    def __init__(self, source='auto', target='en', preset='gemini', **options):
        Engine.__init__(self, source, target, **options)
        name, url, model = self.PRESETS[preset]
        self.key = preset
        self.name = name
        self.url = (options.get('url') or url).rstrip('/')
        self.model = options.get('model') or model
        self.api_key = options.get('api_key', '')
        self.max_items = int(options.get('batch') or 150)
        self.delay = float(options.get('delay') or 0)
        self._last_call = 0.0

    @property
    def signature(self):
        return '%s:%s' % (self.key, self.model)

    def translate(self, lines, context=None):
        wait = self.delay - (time.time() - self._last_call)
        if wait > 0:
            sleep(wait)
        system = AI_PROMPT.format(source=language_name(self.source),
                                  target=language_name(self.target), count=len(lines))
        user = json.dumps({'context_before': context or [], 'lines': lines},
                          ensure_ascii=False)
        payload = {'model': self.model, 'temperature': 0.2,
                   'messages': [{'role': 'system', 'content': system},
                                {'role': 'user', 'content': user}]}
        headers = {'Authorization': 'Bearer ' + self.api_key} if self.api_key else {}
        try:
            raw = http_request(self.url + '/chat/completions', payload, headers, timeout=300)
        finally:
            self._last_call = time.time()
        try:
            content = json.loads(raw)['choices'][0]['message']['content']
        except (ValueError, KeyError, IndexError, TypeError):
            raise MismatchError('Unexpected AI response')
        result = parse_json_array(content)
        if result is None:
            raise MismatchError('AI did not return a JSON array')
        return [u'%s' % item if item is not None else u'' for item in result]


def parse_json_array(content):
    content = re.sub(r'^```(?:json)?|```$', '', (content or '').strip(), flags=re.M).strip()
    start, end = content.find('['), content.rfind(']')
    if start < 0 or end <= start:
        return None
    try:
        result = json.loads(content[start:end + 1])
    except ValueError:
        return None
    return result if isinstance(result, list) else None


# key -> (factory, needs an API key)
ENGINES = {
    'gemini': (lambda s, t, **o: OpenAICompatible(s, t, 'gemini', **o), True),
    'groq': (lambda s, t, **o: OpenAICompatible(s, t, 'groq', **o), True),
    'openrouter': (lambda s, t, **o: OpenAICompatible(s, t, 'openrouter', **o), True),
    'ollama': (lambda s, t, **o: OpenAICompatible(s, t, 'ollama', **o), False),
    'custom': (lambda s, t, **o: OpenAICompatible(s, t, 'custom', **o), False),
    'google': (GoogleFree, False),
    'deepl': (DeepLFree, True),
    'libre': (LibreTranslate, False),
}


def create(key, source, target, **options):
    """Return an engine, or None when it needs an API key that is missing."""
    factory, needs_key = ENGINES[key]
    if needs_key and not options.get('api_key'):
        return None
    return factory(source, target, **options)
