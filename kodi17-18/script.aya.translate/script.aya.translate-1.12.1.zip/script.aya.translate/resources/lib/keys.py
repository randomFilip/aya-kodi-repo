# -*- coding: utf-8 -*-
"""Getting API keys into Kodi without typing them on the TV.

* Key file: a .txt file with lines like ``gemini=AIza...`` (or just the bare
  keys). Imported from Settings > Engines > "Import keys from a file", or
  automatically when it's dropped into the add-on's data folder as aya-keys.txt.
* QR code: Settings > Engines > "Get a free key with your phone" shows a QR code
  that opens the provider's key page on the phone."""
import re
import threading

import xbmcgui

from . import kodiutils as ku

AUTO_IMPORT_NAME = 'aya-keys.txt'

# provider -> (setting id, key page, label string id). The QR images in
# resources/media/qr-<provider>.png encode these URLs (tools/make_qr.py).
PROVIDERS = [
    ('gemini', 'gemini_key', 'https://aistudio.google.com/apikey', 32010),
    ('groq', 'groq_key', 'https://console.groq.com/keys', 32012),
    ('openrouter', 'openrouter_key', 'https://openrouter.ai/keys', 32013),
    ('deepl', 'deepl_key', 'https://www.deepl.com/pro-api', 32016),
]
KEY_PAGES = dict((p[0], p[2]) for p in PROVIDERS)

# Settings a key file may set (name in the file -> setting id)
NAMES = {
    'gemini': 'gemini_key', 'google_ai': 'gemini_key', 'google_gemini': 'gemini_key',
    'groq': 'groq_key',
    'openrouter': 'openrouter_key', 'open_router': 'openrouter_key',
    'deepl': 'deepl_key',
    'libre': 'libre_key', 'libretranslate': 'libre_key',
    'custom': 'custom_key',
}
OTHER_SETTINGS = ('gemini_model', 'groq_model', 'openrouter_model', 'ollama_url', 'ollama_model',
                  'custom_url', 'custom_model', 'libre_url', 'target_lang', 'source_lang',
                  'languages')
LABELS = {'gemini_key': 'Gemini', 'groq_key': 'Groq', 'openrouter_key': 'OpenRouter',
          'deepl_key': 'DeepL', 'libre_key': 'LibreTranslate', 'custom_key': 'Custom AI'}


def guess_provider(key):
    """Recognise a bare key by its shape."""
    if key.startswith('AIza'):
        return 'gemini_key'
    if key.startswith('gsk_'):
        return 'groq_key'
    if key.startswith('sk-or-'):
        return 'openrouter_key'
    if key.endswith(':fx'):
        return 'deepl_key'
    return None


def setting_for(name):
    name = re.sub(r'[\s\-]+', '_', name.strip().lower())
    if name in OTHER_SETTINGS:
        return name
    for suffix in ('_api_key', '_apikey', '_key'):
        if name.endswith(suffix):
            name = name[:-len(suffix)]
            break
    return NAMES.get(name)


def parse(text):
    """Key file text -> ({setting id: value}, [lines that were not understood]).

    Understands ``gemini=KEY``, ``GEMINI_API_KEY=KEY``, ``groq key = KEY``,
    quoted values, comments (#) and bare keys on their own line."""
    found, unknown = {}, []
    for raw in text.replace(u'﻿', u'').splitlines():
        line = raw.strip()
        if not line or line.startswith(('#', ';', '//')):
            continue
        if '=' in line:
            name, value = line.split('=', 1)
            setting = setting_for(name)
        else:
            name, value = '', line
            setting = guess_provider(line)
        value = value.strip().strip('"\'').strip()
        if is_placeholder(value):
            continue  # template line the user hasn't filled in yet
        if setting and value:
            found[setting] = value
        else:
            unknown.append(name.strip() or mask(value))
    return found, unknown


def is_placeholder(value):
    upper = value.upper()
    return upper.startswith(('PASTE', 'YOUR_', 'YOUR ', '<')) or upper in ('KEY', 'YOUR_KEY', '...')


def mask(value):
    return value if len(value) <= 10 else u'%s…%s' % (value[:4], value[-4:])


def apply(found):
    for setting, value in found.items():
        ku.set_setting(setting, value)
    names = [LABELS.get(s, s) for s in sorted(found)]
    ku.log(u'Imported settings: %s' % u', '.join(
        u'%s=%s' % (s, mask(v) if s.endswith('_key') else v) for s, v in sorted(found.items())))
    return names


def read_text(path):
    return ku.read_bytes(path).decode('utf-8-sig', 'replace')


def import_from_file():
    """Settings button: pick a .txt file (USB stick, network share...)."""
    path = ku.browse_file(ku.string(32105), '.txt')
    if not path:
        return False
    found, _ = parse(read_text(path))
    name = ku.split(path)[1]
    if not found:
        xbmcgui.Dialog().ok(ku.to_kodi(ku.addon_info('name')), ku.to_kodi(ku.string(32107) % name))
        return False
    imported = apply(found)
    message = ku.string(32106) % u', '.join(imported) + u'[CR][CR]' + ku.string(32108)
    if ku.yesno(ku.addon_info('name'), message):
        ku.delete(path)
    return True


def auto_import():
    """aya-keys.txt dropped into userdata/addon_data/script.aya.translate/
    (e.g. over the network): import it and delete it. Returns True if done."""
    path = ku.profile_dir() + AUTO_IMPORT_NAME
    if not ku.exists(path):
        return False
    found, _ = parse(read_text(path))
    ku.delete(path)
    if found:
        ku.notify(ku.string(32113) % u', '.join(apply(found)), 8000)
    else:
        ku.notify(ku.string(32107) % AUTO_IMPORT_NAME, 8000)
    return bool(found)


# ----------------------------------------------------------------- QR --
CLOSE_IGNORED = (0, 107)  # no-op, mouse move
ENGINE_PROVIDER = {0: 'gemini', 2: 'groq', 3: 'openrouter', 6: 'deepl'}


class QRWindow(xbmcgui.WindowDialog):
    """Full-screen QR code with instructions. Coordinates are in Kodi's
    1280x720 skin space, so it looks the same on every skin and screen."""

    def __init__(self, title, image, text):
        xbmcgui.WindowDialog.__init__(self)
        white = '0xFFFFFFFF'
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, ku.to_kodi(ku.media_path('background.png'))))
        self.addControl(xbmcgui.ControlLabel(0, 30, 1280, 40, ku.to_kodi(title), font='font13',
                                             textColor=white, alignment=0x00000002))
        self.addControl(xbmcgui.ControlImage(80, 110, 420, 420, ku.to_kodi(image)))
        steps = xbmcgui.ControlTextBox(560, 110, 680, 480, font='font13', textColor=white)
        self.addControl(steps)
        steps.setText(ku.to_kodi(text))
        self.addControl(xbmcgui.ControlLabel(0, 640, 1280, 40, ku.to_kodi(ku.string(32112)),
                                             font='font13', textColor='0xFFAAB4C8',
                                             alignment=0x00000002))

    def onAction(self, action):
        if action.getId() not in CLOSE_IGNORED:
            self.close()


def selected_provider():
    return ENGINE_PROVIDER.get(ku.setting_int('engine', 0), 'gemini')


def provider_label(label_id):
    return ku.string(label_id).split(' (')[0]  # "Google Gemini AI (free key)" -> "Google Gemini AI"


def receive(text, provider):
    """Text from the phone page -> saved keys. A bare key that can't be
    recognised by its shape is saved for the service chosen on the page."""
    found, _ = parse(text)
    if not found:
        token = text.strip().split()[0] if text.strip() else u''
        setting = dict((p[0], p[1]) for p in PROVIDERS).get(provider)
        if token and setting and len(text.split()) == 1 and not is_placeholder(token):
            found = {setting: token}
    return apply(found) if found else []


def show_qr():
    """Settings button "Add a key from your phone": QR code -> page served by
    this add-on -> the key pasted on the phone is saved here."""
    from . import pairing, qr
    ip = ku.local_ip()
    providers = [(p[0], provider_label(p[3]), p[2]) for p in PROVIDERS]
    server = pairing.PairingServer(receive, providers, selected_provider(),
                                   title=ku.addon_info('name'))
    url = server.start(ip) if ip else None
    if not url:
        ku.log(u'Phone pairing unavailable (ip=%s), showing the key page QR instead' % ip)
        ku.notify(ku.string(32117))
        return show_page_qr(selected_provider())
    image = ku.profile_dir('qr') + u'pair-%s.png' % server.token  # unique: Kodi caches images by path
    ku.write_bytes(image, qr.png(qr.encode(url)))
    window = QRWindow(ku.string(32114), image, ku.string(32115) % url)

    def close_when_done():
        server.done.wait()
        window.close()

    watcher = threading.Thread(target=close_when_done)
    watcher.daemon = True
    watcher.start()
    try:
        window.doModal()
    finally:
        server.done.set()  # release the watcher if the user closed the screen
        server.stop()
        ku.delete(image)
    # no `del window` here: Python 2 (Kodi 17/18) forbids deleting a name an
    # inner function uses; it goes away when show_qr returns
    if server.saved:
        ku.notify(ku.string(32116) % u', '.join(server.saved), 8000)
    return server.saved


def show_page_qr(provider=None):
    """Fallback without network pairing: QR code that only opens the key page."""
    chosen = [p for p in PROVIDERS if p[0] == (provider or selected_provider())]
    name, _, url, label_id = chosen[0]
    window = QRWindow(ku.string(32110) % provider_label(label_id),
                      ku.media_path('qr-%s.png' % name), ku.string(32111) % url)
    window.doModal()
    del window
    return name
