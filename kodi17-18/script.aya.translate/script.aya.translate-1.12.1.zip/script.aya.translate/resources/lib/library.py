# -*- coding: utf-8 -*-
"""The AYA library: every translation is also kept in a folder of your choice
(USB stick, NAS, network share), one folder per movie or show, so nothing is
lost when Kodi is reinstalled. Each subtitle gets a .json info file next to
it (title, year, IMDb id, source subtitle, engine, date): the details a
subtitle site asks for when you upload."""
import json
import re
import time

from . import kodiutils as ku

INFO_VERSION = 1


def clean(name):
    """Safe file/folder name on every OS and on network shares."""
    name = re.sub(r'[\\/:*?"<>|\r\n\t]+', ' ', name or u'')
    name = re.sub(r'\s+', ' ', name).strip().strip('.').strip()
    return name[:100]


def entry(info, fallback_name):
    """(folders, base name) for a movie, an episode or a plain file."""
    show, title, year = clean(info.get('show')), clean(info.get('title')), info.get('year') or 0
    season, episode = info.get('season'), info.get('episode')
    if show and season is not None and season >= 0 and episode is not None and episode > 0:
        return [show, u'Season %02d' % season], u'%s S%02dE%02d' % (show, season, episode)
    if title:
        base = u'%s (%d)' % (title, year) if year else title
        return [base], base
    base = clean(fallback_name) or u'subtitle'
    return [base], base


def root():
    folder = ku.setting('library_folder')
    return folder if folder else ku.profile_dir('library')


def save(translated_path, video_path, source_path, target, language_tag, details, info):
    """Copy the translation into the library with its info file.
    Returns the library path of the subtitle, or None when switched off."""
    if not ku.setting_bool('save_library'):
        return None
    fallback = ku.split(ku.unstack(video_path or source_path)[0])[1].split('?')[0]
    if '.' in fallback:
        fallback = fallback.rsplit('.', 1)[0]
    if ku.is_stream(video_path or ''):
        fallback = ku.split(source_path)[1].rsplit('.', 1)[0]
    folders, base = entry(info, fallback)
    folder = root()
    for part in folders:
        folder = ku.join(folder, part)
    folder += '/' if '://' in folder or '\\' not in folder else '\\'
    if not ku.exists(folder):
        ku.mkdirs(folder)
    subtitle = ku.join(folder, u'%s.%s.srt' % (base, language_tag))
    if not ku.copy(translated_path, subtitle):
        raise IOError(u'could not write %s' % subtitle)
    record = {
        'aya_info_version': INFO_VERSION,
        'title': info.get('title') or None,
        'original_title': info.get('original_title') or None,
        'year': info.get('year') or None,
        'imdb': info.get('imdb') or None,
        'show': info.get('show') or None,
        'season': info.get('season') if info.get('show') else None,
        'episode': info.get('episode') if info.get('show') else None,
        'language': ku.base_language(target),
        'script': ku.script_of(target),
        'source_subtitle': ku.split(source_path)[1],
        'source_language': details.get('source_language'),
        'video_file': ku.split(ku.unstack(video_path)[0])[1] if video_path and not ku.is_stream(video_path) else None,
        'engine': details.get('engine'),
        'fallback_engine_used': details.get('fallback'),
        'machine_translated': details.get('engine') != 'script-conversion',
        'translated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'uploaded_to': [],
    }
    text = json.dumps(record, indent=2, ensure_ascii=False, sort_keys=True)
    ku.write_bytes(subtitle[:-4] + '.json', (text if isinstance(text, bytes) else text.encode('utf-8')))
    ku.log(u'Library: saved %s' % subtitle)
    return subtitle
