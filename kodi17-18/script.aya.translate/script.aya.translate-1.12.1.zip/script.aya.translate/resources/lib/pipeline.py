# -*- coding: utf-8 -*-
"""Cues in -> translated cues out: batching, sentence joining, line-count
checks, fallback engine and progress. Pure Python (no Kodi imports)."""
from collections import OrderedDict

from . import srt, textproc
from .engines import EngineError, MismatchError, take_batch

CONTEXT_LINES = 3
FIRST_BATCH = 40  # small first request, so the first progress shows up within seconds


class Cancelled(Exception):
    pass


class _Unit(object):
    __slots__ = ('text', 'cue', 'start', 'end', 'dialog')

    def __init__(self, text, cue, start, end, dialog):
        self.text = text
        self.cue = cue
        self.start = start
        self.end = end
        self.dialog = dialog


def translate_cues(cues, engine, fallback=None, width=42, join_sentences=True,
                   progress=None, is_cancelled=None, on_fallback=None, on_batch=None):
    templates, units = [], []
    for index, cue in enumerate(cues):
        template, texts = textproc.disassemble(cue.text)
        templates.append(template)
        units.extend(_Unit(t, index, cue.start, cue.end, template.dialog) for t in texts)

    todo = [u for u in units if textproc.needs_translation(u.text)]
    # AI engines see the neighbouring lines and handle split sentences themselves;
    # classic engines get whole sentences, which are split back afterwards.
    if engine.contextual or not join_sentences:
        groups = [[u] for u in todo]
    else:
        groups = textproc.group_sentences(todo)
    sources = [textproc.join_units([u.text for u in g]) for g in groups]

    runner = _Runner(engine, fallback, progress, is_cancelled, on_fallback, on_batch)
    for group, source, text in zip(groups, sources, runner.run(sources)):
        text = textproc.match_capital(source, text)
        if len(group) == 1:
            group[0].text = text
        else:
            parts = textproc.split_proportional(text, [len(u.text) for u in group])
            for unit, part in zip(group, parts):
                unit.text = part

    per_cue = [[] for _ in cues]
    for unit in units:
        per_cue[unit.cue].append(unit.text)
    result = []
    for cue, template, texts in zip(cues, templates, per_cue):
        text = textproc.assemble(template, texts, width)
        if text.strip():
            result.append(srt.Cue(cue.start, cue.end, text, cue.extra))
    return result


class _Runner(object):
    def __init__(self, engine, fallback, progress, is_cancelled, on_fallback, on_batch=None):
        self.engine = engine
        self.fallback = fallback
        self.progress = progress
        self.is_cancelled = is_cancelled
        self.on_fallback = on_fallback
        self.on_batch = on_batch

    def run(self, lines):
        if self.engine.contextual:
            return self._translate_all(lines)
        # classic engines: translate every distinct line once
        unique = list(OrderedDict.fromkeys(lines))
        mapping = dict(zip(unique, self._translate_all(unique)))
        return [mapping[line] for line in lines]

    def _translate_all(self, lines):
        out, start = [], 0
        while start < len(lines):
            if self.is_cancelled and self.is_cancelled():
                raise Cancelled()
            engine = self.engine
            limit = engine.max_items if start else min(engine.max_items, FIRST_BATCH)
            batch = take_batch(lines, start, limit, engine.max_chars)
            context = lines[max(0, start - CONTEXT_LINES):start]
            if self.on_batch:
                self.on_batch(engine, start, len(lines))
            try:
                translated = self._checked(engine, batch, context)
            except EngineError as error:
                if self.fallback is None:
                    raise
                if self.on_fallback:
                    self.on_fallback(engine, self.fallback, error)
                self.engine, self.fallback = self.fallback, None
                continue  # retry the same lines with the fallback engine
            out.extend(translated)
            start += len(batch)
            if self.progress:
                self.progress(start, len(lines))
        return out

    def _checked(self, engine, batch, context):
        """Translate and verify we got exactly one line back per line sent.
        On a mismatch, halve the batch until it works."""
        try:
            result = engine.translate(batch, context)
            if len(result) == len(batch):
                return result
        except MismatchError:
            pass
        if len(batch) == 1:
            raise MismatchError('%s returned unusable output' % engine.name)
        if self.is_cancelled and self.is_cancelled():
            raise Cancelled()
        middle = len(batch) // 2
        first = self._checked(engine, batch[:middle], context)
        second = self._checked(engine, batch[middle:],
                               (context + batch[:middle])[-CONTEXT_LINES:])
        return first + second
