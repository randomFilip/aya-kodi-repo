# -*- coding: utf-8 -*-
"""AYA Translate, manual mode (Add-ons menu or a remote key).
Map it to a key in userdata/keymaps/keyboard.xml, e.g.
    <f8>RunScript(script.aya.translate)</f8>"""
from resources.lib import manual

manual.main()
