# -*- coding: utf-8 -*-
"""Kodi glue: settings -> engines, cache, translate, save, load into the player."""
import hashlib
import re
import time

import xbmc

from . import engines, finder, kodiutils as ku, library, messages, pipeline, srt, translit
from .engines import EngineError

# Problems the user has to fix in the settings: shown as a dialog (OK button),
# the rest (limits, network...) as a notification.
CONFIG_KINDS = ('auth', 'not_found', 'refused', 'file')
# kind -> (short text id for notifications, long text id for dialogs)
ERROR_TEXTS = {
    'auth': (32160, 32150), 'quota': (32161, 32151), 'not_found': (32162, 32152),
    'refused': (32163, 32153), 'network': (32164, 32154), 'timeout': (32165, 32155),
    'server': (32166, 32156), 'mismatch': (32167, 32157), 'file': (32169, 32158),
}

CACHE_VERSION = '1'
# Order of the "engine" / "fallback" options in settings.xml
ENGINE_KEYS = ['gemini', 'google', 'groq', 'openrouter', 'ollama', 'custom', 'deepl', 'libre']


def _engine_options(key):
    options = {'batch': ku.setting_int('ai_batch', 150), 'delay': ku.setting_int('ai_delay', 2)}
    if key in ('gemini', 'groq', 'openrouter', 'custom', 'deepl', 'libre'):
        options['api_key'] = ku.setting(key + '_key')
    if key in ('gemini', 'groq', 'openrouter', 'ollama', 'custom'):
        options['model'] = ku.setting(key + '_model')
    if key in ('ollama', 'custom', 'libre'):
        options['url'] = ku.setting(key + '_url')
    return options


def source_language(source_path):
    """Setting, or the language Kodi put in the file name (Movie.sr.srt), or auto."""
    configured = ku.setting('source_lang').lower()
    if configured and configured != 'auto':
        return configured
    return finder.language_code(ku.split(source_path)[1]) or 'auto'


def valid_language(code):
    """'mk', 'sr-latn', 'pt-br' are fine; 'macedonian' or 'm k' are not."""
    return bool(code) and (code in engines.LANGUAGE_NAMES
                           or re.match(r'^[a-z]{2,3}(-[a-z]{2,4})?$', code) is not None)


def engine_label(engine):
    return getattr(engine, 'name', None) or u'?'


def friendly(error, engine_name=None, url=None):
    """(short text for a notification, full explanation for a dialog)."""
    engine_name = engine_name or getattr(error, 'engine_name', None) or u'?'
    url = url or getattr(error, 'engine_url', None) or u''
    kind = getattr(error, 'kind', 'other')
    if kind in ERROR_TEXTS:
        short_id, long_id = ERROR_TEXTS[kind]
        if kind == 'refused':
            full = ku.string(long_id) % (engine_name, url or engine_name)
        elif kind == 'file':
            full = ku.string(long_id) % (getattr(error, 'detail', u'') or u'')
        else:
            full = ku.string(long_id) % engine_name
        return u'%s: %s' % (engine_name, ku.string(short_id)), full
    text = error_text(error)
    return u'%s: %s' % (engine_name, text[:80]), ku.string(32159) % (engine_name, text)


def build_engines(target, source='auto', quiet=False):
    """Returns (engine, fallback). Without an API key for the chosen engine,
    the fallback (or Google) is used and the user is told how to fix it."""
    keys = [ENGINE_KEYS[i] if 0 <= i < len(ENGINE_KEYS) else None
            for i in (ku.setting_int('engine', 0), ku.setting_int('fallback', 1))]
    primary_key, fallback_key = keys
    primary_key = primary_key or 'google'
    primary = engines.create(primary_key, source, target, **_engine_options(primary_key))
    fallback = None
    if fallback_key and fallback_key != primary_key:
        fallback = engines.create(fallback_key, source, target, **_engine_options(fallback_key))
    if primary is None:
        primary = fallback or engines.create('google', source, target)
        fallback = None
        if not quiet:
            ku.notify(ku.string(32070) % (primary_key.capitalize(), primary.name), 8000)
    return primary, fallback


def write_text(path, text):
    return ku.write_bytes(path, text.encode('utf-8'))


def error_text(error):
    """Exception message as text on Python 2 and 3."""
    return ku.to_text(error.args[0]) if error.args else repr(error)


def output_name(video_or_source, target):
    first = ku.unstack(video_or_source)[0]  # multi-part movie: name after part 1
    if ku.is_stream(first):
        base = u'stream'
    else:
        base = ku.split(first)[1].rsplit('.', 1)[0]
    base = re.sub(r'[\\/:*?"<>|]+', '_', base)[:120] or u'subtitle'
    # Kodi reads the language from the first tag and shows the rest as the
    # track name: "Serbian - latin translated"
    return u'%s.%s.translated.srt' % (base, language_tag(target))


def language_tag(target):
    """'mk' -> 'mk', 'sr-latn' -> 'sr.latin', 'sr-cyrl' -> 'sr.cyrillic'"""
    script = {'latn': '.latin', 'cyrl': '.cyrillic'}.get(ku.script_of(target), '')
    return u'%s%s' % (ku.base_language(target), script)


def translate_file(source_path, name, background, target):
    """Returns (path of the translated file, details for the library)."""
    data = ku.read_bytes(source_path)
    source = source_language(source_path)
    script = ku.script_of(target)
    encoding = ku.setting('fallback_encoding') or 'cp1250'
    details = {'source_language': source, 'engine': None, 'fallback': None}
    if script and ku.base_language(source) == ku.base_language(target):
        # Serbian -> Serbian: only change the alphabet. Instant, free, no engine.
        ku.log('Converting %s to %s script' % (source_path, script))
        cues = translit.convert_cues(srt.parse(srt.decode(data, encoding)), script)
        details['engine'] = 'script-conversion'
        return _save(srt.compose(cues), name), details

    engine, fallback = build_engines(target, source)
    details['engine'] = engine.signature
    digest = hashlib.sha1(data + (u'|%s|%s|%s' % (target, engine.signature, CACHE_VERSION))
                          .encode('utf-8')).hexdigest()[:20]
    cache_path = ku.profile_dir('cache') + digest + '.srt'

    if ku.exists(cache_path):
        ku.log('Cache hit for %s' % source_path)
        text = ku.read_bytes(cache_path).decode('utf-8')
    else:
        cues = srt.parse(srt.decode(data, encoding))
        if not cues:
            raise EngineError(u'No subtitles in %s' % ku.split(source_path)[1], 'file',
                              detail=ku.split(source_path)[1])
        engines.sleep = lambda seconds: xbmc.Monitor().waitForAbort(seconds)
        engines.CA_FILE = ku.ca_bundle()
        ku.log('Translating %d cues with %s (fallback: %s)'
               % (len(cues), engine.signature, fallback.signature if fallback else 'none'))
        progress = ku.Progress(messages.heading(target, engines.LANGUAGE_NAMES), background)
        current = [engine]

        def switched(old, new, error):
            short, _ = friendly(error, old.name, getattr(old, 'url', None))
            ku.log(u'%s failed (%s), switching to %s' % (old.name, error_text(error), new.name),
                   xbmc.LOGWARNING)
            ku.notify(u'%s  \u2192  %s' % (short, new.name), 8000)
            details['fallback'] = new.signature
            current[0] = new

        try:
            translated = pipeline.translate_cues(
                cues, engine, fallback,
                width=ku.setting_int('line_width', 42),
                join_sentences=ku.setting_bool('join_sentences'),
                progress=progress.update, is_cancelled=progress.cancelled,
                on_fallback=switched,
                on_batch=lambda used, start, total: progress.working(used.name, total))
        except EngineError as error:
            error.engine_name = current[0].name
            error.engine_url = getattr(current[0], 'url', None)
            raise
        finally:
            progress.close()
        if script:  # guarantee the chosen alphabet whatever the engine returned
            translit.convert_cues(translated, script)
        text = srt.compose(translated)
        write_text(cache_path, text)

    return _save(text, name), details


def _save(text, name):
    destination = ku.profile_dir('translated') + name
    write_text(destination, text)
    return destination


def copy_next_to(folder_of, path, name):
    first = ku.unstack(folder_of)[0]
    if ku.is_stream(first):
        return None
    destination = ku.join(ku.video_folder(first), name)
    return destination if ku.copy(path, destination) else None


def choose_language(subtitle_name=None):
    """Ask which language to translate into (default first). None = cancelled."""
    default = ku.target_language()
    codes = [default] + [c for c in ku.choosable_languages() if c != default]
    labels = [engines.language_name(c) for c in codes]
    labels[0] += u'  *'
    heading = ku.string(32073) % subtitle_name if subtitle_name else ku.string(32060)
    choice = ku.select(heading, labels + [ku.string(32074)])
    return codes[choice] if 0 <= choice < len(codes) else None


def run(source_path, video_path=None, background=None, target=None):
    """Translate `source_path`; load it into the player if `video_path` is playing.
    Returns the path of the translated file or None."""
    if background is None:
        background = ku.playing_video() is not None
    target = (target or ku.target_language()).strip().lower()
    if not valid_language(target):
        ku.ok(ku.addon_info('name'), ku.string(32134) % target)
        return None
    name = output_name(video_path or source_path, target)
    info = ku.video_info() if video_path and ku.playing_video() == video_path else {}
    started = time.time()
    ku.log(u'Translate %s into %s%s' % (
        ku.split(source_path)[1], target,
        u' for %s' % ku.split(ku.unstack(video_path)[0].split('?')[0])[1] if video_path else u''))
    try:
        result, details = translate_file(source_path, name, background, target)
    except pipeline.Cancelled:
        ku.log(u'Cancelled after %.0f s' % (time.time() - started))
        ku.notify(messages.phrase('cancelled', target))
        return None
    except EngineError as error:
        short, full = friendly(error)
        ku.log(u'Translation failed: %s (%s)' % (error_text(error), getattr(error, 'kind', '')),
               xbmc.LOGERROR)
        if getattr(error, 'kind', None) in CONFIG_KINDS:
            ku.ok(messages.phrase('failed', target), full)  # needs fixing: make sure it's seen
        else:
            ku.notify(u'%s: %s' % (messages.phrase('failed', target), short), 10000)
        return None

    try:
        library.save(result, video_path, source_path, target, language_tag(target), details, info)
    except Exception as error:  # pylint: disable=broad-except  # never block playback for it
        ku.log(u'Library: %s' % error_text(error), xbmc.LOGWARNING)
        ku.notify(ku.string(32168) % (ku.setting('library_folder') or u'library'), 8000)

    ku.log(u'Done in %.1f s with %s%s: %s' % (
        time.time() - started, details.get('engine'),
        u' (then %s)' % details['fallback'] if details.get('fallback') else u'', name))
    if video_path:
        if ku.setting_bool('save_next_to_video'):
            copy_next_to(video_path, result, name)
        if ku.playing_video() == video_path:
            ku.set_subtitles(result)
            ku.notify(messages.phrase('done', target))
    else:
        saved = copy_next_to(source_path, result, name) or result
        ku.notify(ku.string(32067) % ku.split(saved)[1])
    return result


def check_setup():
    """Settings button "Test my setup": language, a short test translation with
    the main and the fallback engine, and the library folder."""
    ok, bad = u'[COLOR lime]OK[/COLOR]', u'[COLOR red]%s[/COLOR]' % ku.string(32141)
    lines = []
    target = ku.target_language().strip().lower()
    if valid_language(target):
        lines.append(u'%s  %s' % (ok, ku.string(32133) % engines.language_name(target)))
    else:
        lines.append(u'%s  %s' % (bad, ku.string(32134) % target))
        target = u'en'
    engine, fallback = build_engines(target, 'en', quiet=True)
    wanted = ENGINE_KEYS[ku.setting_int('engine', 0)] if 0 <= ku.setting_int('engine', 0) < len(ENGINE_KEYS) else None
    if wanted and engine.key != wanted and not engine.key.startswith(wanted):
        lines.append(u'%s  %s' % (bad, ku.string(32142) % (wanted.capitalize(), engine.name)))
    engines.sleep = lambda seconds: xbmc.Monitor().waitForAbort(seconds)
    engines.CA_FILE = ku.ca_bundle()
    for label_id, candidate in ((32135, engine), (32136, fallback)):
        if candidate is None:
            if label_id == 32136:
                lines.append(u'%s  %s' % (bad, ku.string(32140)))
            continue
        try:
            sample = candidate.translate([u'Hello, how are you?'], [])
            result = u'%s  "%s"' % (ok, (sample[0] if sample else u'')[:60])
        except EngineError as error:
            result = u'%s  %s' % (bad, friendly(error, candidate.name, getattr(candidate, 'url', None))[1])
        lines.append(ku.string(label_id) % (candidate.name, result))
    lines.append(_check_library(ok, bad))
    report = u'[CR][CR]'.join(lines)
    ku.log(u'Setup check: %s' % report.replace(u'[CR]', u' | '))
    ku.textviewer(ku.string(32132), report)
    return lines


def _check_library(ok, bad):
    if not ku.setting_bool('save_library'):
        return ku.string(32138) % ku.string(32143)
    folder = library.root()
    probe = ku.join(folder, u'.aya-write-test')
    try:
        if not ku.exists(folder):
            ku.mkdirs(folder)
        writable = bool(ku.write_bytes(probe, b'ok')) and ku.exists(probe)
        ku.delete(probe)
    except Exception:  # pylint: disable=broad-except
        writable = False
    return ku.string(32138) % (u'%s  %s' % (ok, folder) if writable
                               else u'%s  %s' % (bad, ku.string(32139) % folder))
