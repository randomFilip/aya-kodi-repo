# -*- coding: utf-8 -*-
"""Find subtitle files that belong to the playing video.

Where Kodi saves a subtitle from its "Download" dialog (same logic in Kodi 17-21):
  1. downloaded into the custom subtitle folder (Settings > Player > Language >
     "Custom subtitle folder") if set, otherwise into special://temp
  2. then copied next to the video when "Subtitle storage location" is
     "Next to the video" and that folder is writable
  3. file name: <video name>.<iso 639-1>.srt (streams: TempSubtitle.<lang>.srt)
All special:// paths are resolved by Kodi itself, so this works the same on
Windows, Linux, macOS, Android, LibreELEC/CoreELEC/OSMC, iOS/tvOS and Xbox."""
import re
import time

from . import kodiutils as ku
from . import srt, translit
from .engines import LANGUAGE_NAMES

SUBTITLE_EXTENSIONS = ('.srt',)
OUR_MARKER = 'translated'

# Add-ons that download movies (and their subtitles) to a folder: add-on id ->
# setting ids holding those folders. Their videos play from a local web
# address (http://127.0.0.1:...), so the video path doesn't tell us the folder.
DOWNLOADER_ADDONS = (
    ('plugin.video.elementum', ('download_path', 'completed_movies_path', 'completed_shows_path')),
)

# Language names and ISO 639-2 codes seen in subtitle file names -> ISO 639-1
NAME_CODES = dict((name.lower(), code) for code, name in LANGUAGE_NAMES.items()
                  if code != 'auto' and '-' not in code and ' ' not in name)
NAME_CODES.update({
    'eng': 'en', 'ger': 'de', 'deu': 'de', 'fre': 'fr', 'fra': 'fr', 'spa': 'es', 'ita': 'it',
    'srp': 'sr', 'scc': 'sr', 'hrv': 'hr', 'scr': 'hr', 'bos': 'bs', 'mac': 'mk', 'mkd': 'mk',
    'bul': 'bg', 'alb': 'sq', 'sqi': 'sq', 'gre': 'el', 'ell': 'el', 'tur': 'tr', 'rus': 'ru',
    'por': 'pt', 'pol': 'pl', 'cze': 'cs', 'ces': 'cs', 'slv': 'sl', 'slo': 'sk', 'slk': 'sk',
    'hun': 'hu', 'rum': 'ro', 'ron': 'ro', 'dut': 'nl', 'nld': 'nl', 'ukr': 'uk', 'ara': 'ar',
    'heb': 'he', 'chi': 'zh', 'zho': 'zh', 'jpn': 'ja', 'kor': 'ko', 'swe': 'sv', 'nor': 'no',
    'dan': 'da', 'fin': 'fi', 'serbian': 'sr', 'croatian': 'hr', 'bosnian': 'bs',
    'macedonian': 'mk', 'slovenian': 'sl', 'portuguese': 'pt', 'brazilian': 'pt',
})
for _code in list(LANGUAGE_NAMES):
    if _code != 'auto' and '-' not in _code:
        NAME_CODES.setdefault(_code, _code)


class Candidate(object):
    def __init__(self, path, name, mtime, place):
        self.path = path
        self.name = name
        self.mtime = mtime
        self.place = place

    def label(self):
        minutes = int(max(0, time.time() - self.mtime) // 60)
        age = u'%d min' % minutes if minutes < 120 else u'%d h' % (minutes // 60)
        return u'%s   [%s, %s]' % (self.name, self.place, age)


def custom_subtitle_folder():
    result = ku.rpc('Settings.GetSettingValue', setting='subtitles.custompath') or {}
    return result.get('value') or ''


def _subtitle_folders(folder, label, rule):
    return [(folder, label, rule), (ku.join(folder, 'Subs') + '/', label, rule),
            (ku.join(folder, 'subs') + '/', label, rule)]


def search_folders(video_path):
    """(folder, place label, rule) in priority order. rule 'any': the folder
    holds only this video, so every subtitle in it belongs to it; rule
    'match': the subtitle's name must match the video."""
    folders = []
    for part in ku.unstack(video_path):
        if part and not ku.is_stream(part):
            folder = ku.video_folder(part)
            rule = 'any' if only_video_in(folder, part) else 'match'
            folders += _subtitle_folders(folder, u'video folder', rule)
    custom = custom_subtitle_folder()
    if custom:
        folders.append((custom, u'subtitle folder', 'match'))
    extra = ku.setting('extra_subtitle_folder')
    if extra:
        folders.append((extra, u'my subtitle folder', 'match'))
    for root, label in downloader_folders():
        folders.append((root, label, 'match'))
        for sub in movie_subfolders(root, video_path):
            rule = 'any' if only_video_in(sub, video_path) else 'match'
            folders += _subtitle_folders(sub, label, rule)
    folders += [('special://temp/', u'Kodi temp', 'match'),
                ('special://temp/subtitles/', u'Kodi temp', 'match')]
    seen, unique = set(), []
    for entry in folders:
        if entry[0] not in seen:
            seen.add(entry[0])
            unique.append(entry)
    return unique


def downloader_folders():
    """Download folders of installed add-ons like Elementum: [(folder, label)]."""
    found = []
    for addon_id, setting_ids in DOWNLOADER_ADDONS:
        label = addon_id.split('.')[-1].capitalize()
        for setting_id in setting_ids:
            folder = ku.other_addon_setting(addon_id, setting_id)
            if folder and folder not in [f for f, _ in found]:
                found.append((folder, label))
    return found


def movie_subfolders(root, video_path):
    """Only the folder(s) of THIS movie inside a download folder (named like the
    video), never other movies' folders, however recent."""
    bases = [b for b in video_bases(video_path) if b != u'tempsubtitle']
    bases = [normalize(b, extension=False) for b in bases]
    return [ku.join(root, name) + '/' for name in ku.list_dirs(root)
            if _same_title(normalize(name, extension=False), bases)]


VIDEO_EXTENSIONS = ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.wmv', '.ts', '.m2ts', '.webm',
                    '.mpg', '.mpeg', '.iso', '.flv', '.divx', '.ogm', '.vob')


def only_video_in(folder, video_path):
    """True when the folder holds no other video than the one playing (samples
    and extras don't count), i.e. it's this movie's own folder."""
    playing = set(normalize(ku.split(part)[1]) for part in ku.unstack(video_path or u''))
    for name in ku.list_files(folder):
        lower = name.lower()
        if not lower.endswith(VIDEO_EXTENSIONS) or 'sample' in lower or 'trailer' in lower:
            continue
        if normalize(name) not in playing:
            return False
    return True


def normalize(name, extension=True):
    """'The.Movie_2024 - 1080p.mkv' -> 'the movie 2024 1080p'. extension=False
    for names without one (folders, base names): keeps the last part."""
    base = name.rsplit('.', 1)[0] if extension and '.' in name else name
    return u' '.join(w for w in re.split(r'[._\-\s\[\]()]+', base.lower()) if w)


FLAG_WORDS = ('forced', 'sdh', 'cc', 'hi', 'full', 'default')


def _title_part(normalized):
    """'the movie 2024 en forced' -> 'the movie 2024' (drop language and flags)."""
    words = normalized.split()
    while words and (words[-1] in NAME_CODES or words[-1] in FLAG_WORDS or words[-1].isdigit()
                     and len(words[-1]) < 3):
        words.pop()
    return u' '.join(words)


def _same_title(normalized, bases):
    for base in bases:
        if not base:
            continue
        if normalized.startswith(base) or base.startswith(normalized + u' ') or base == normalized:
            if len(min(normalized, base, key=len)) >= 4:
                return True
    return False


def belongs(name, bases):
    """Does a subtitle file name belong to the video? 'Movie.A.2020.1080p.en.srt'
    or 'Movie A 2020.en.srt' for 'Movie.A.2020.1080p.mkv'."""
    normalized = normalize(name)
    title = _title_part(normalized)
    normalized_bases = [normalize(b, extension=False) for b in bases]
    for base in normalized_bases:
        if normalized.startswith(base) and len(base) >= 4:
            return True
        if title and len(title) >= 6 and (base == title or base.startswith(title + u' ')):
            return True
    return False


def video_bases(video_path):
    """Lower-case file names (without extension) Kodi uses for downloaded subtitles."""
    bases = [u'tempsubtitle']  # Kodi's name for subtitles of streams
    for part in ku.unstack(video_path or ''):
        name = ku.split(part)[1].split('?')[0]
        if '.' in name:
            name = name.rsplit('.', 1)[0]
        if name:
            bases.append(name.lower())
    return bases


def name_tokens(name):
    return name.rsplit('.', 1)[0].lower().split('.')


def language_tokens(name):
    """Words that can say the language: 'Movie.2024.en.forced.srt' -> ['en', 'forced'],
    'Subs/2_English.srt' -> ['english'], 'Macedonian.srt' -> ['macedonian'].
    The first word is skipped (it's the title) unless it's the only one."""
    words = [w for w in re.split(r'[._\-\s\[\]()]+', name.rsplit('.', 1)[0].lower()) if w]
    words = [w for w in words if not w.isdigit()]
    if len(words) > 1:
        words = words[1:]
    return [w for w in words if w not in ('forced', 'sdh', 'cc', 'hi', 'full', 'default')][-2:]


def is_forced(name):
    return 'forced' in re.split(r'[._\-\s\[\]()]+', name.lower())


def is_language(name, aliases):
    """Movie.en.srt / Movie.English.forced.srt / Subs/27_Macedonian.srt."""
    return any(token in aliases for token in language_tokens(name))


def language_code(name):
    """'Movie.2024.sr.srt' -> 'sr', 'Subs/2_English.srt' -> 'en', unknown -> None."""
    for token in reversed(language_tokens(name)):
        if token in NAME_CODES:
            return NAME_CODES[token]
    return None


def best(candidates):
    """The subtitle most worth translating: full (not forced) subtitles first,
    English first (translating from English gives the best results), then newest."""
    if not candidates:
        return None
    return sorted(candidates, key=lambda c: (is_forced(c.name), language_code(c.name) != 'en',
                                             -c.mtime))[0]


def _needs_other_script(path, target):
    """Serbian file, Serbian target with a script: only offer it when the file
    is written in the other script (Cyrillic file, Latin wanted or vice versa)."""
    script = ku.script_of(target)
    if not script:
        return False
    try:
        text = srt.decode(ku.read_bytes(path)[:20000], ku.setting('fallback_encoding'))
    except Exception:  # pylint: disable=broad-except
        return False
    found = translit.dominant_script(text)
    return found is not None and found != script


def find(video_path, target, since=None):
    """Subtitles of the playing video that aren't in the target language yet.
    since: playback start time; Kodi's generic TempSubtitle file only counts
    if it was downloaded after that (else it's left over from another video)."""
    bases = [b for b in video_bases(video_path) if b != u'tempsubtitle']
    aliases = ku.language_aliases(target)
    seen, found = set(), []
    for folder, place, rule in search_folders(video_path):
        for name in ku.list_files(folder):
            if not name.lower().endswith(SUBTITLE_EXTENSIONS):
                continue
            path = ku.join(folder, name)
            if path in seen or OUR_MARKER in name_tokens(name):
                continue
            seen.add(path)
            mtime = ku.mtime(path)
            if name.lower().startswith(u'tempsubtitle'):
                if since is not None and mtime < since - 5:
                    continue  # left over from an earlier stream
            elif rule != 'any' and not belongs(name, bases):
                continue  # another movie's subtitle
            if is_language(name, aliases) and not _needs_other_script(path, target):
                continue  # already in the language (and script) we want
            found.append(Candidate(path, name, mtime, place))
    found.sort(key=lambda c: c.mtime, reverse=True)
    return found
