# -*- coding: utf-8 -*-
"""Settings > Help > "Show the AYA log": read aya.log on the TV, open it on
the phone (QR code, to copy or share it), or clear it."""
import sys

import xbmc

from . import kodiutils as ku

MAX_LINES = 400
COLOURS = ((u' ERROR ', u'red'), (u' WARNING ', u'orange'))


def summary():
    """What the log can't show: versions and the current settings (no keys)."""
    from .core import ENGINE_KEYS
    from .engines import language_name

    def engine(setting_id, default):
        index = ku.setting_int(setting_id, default)
        return ENGINE_KEYS[index] if 0 <= index < len(ENGINE_KEYS) else u'none'

    keys = [u'%s %s' % (name, u'set' if ku.setting(name.lower() + '_key') else u'missing')
            for name in (u'Gemini', u'Groq', u'OpenRouter', u'DeepL')]
    return [
        u'AYA Translate %s, Kodi %s, Python %s' % (
            ku.addon_info('version'), ku.to_text(xbmc.getInfoLabel('System.BuildVersion')),
            sys.version.split()[0]),
        u'Translate into: %s (%s); engine: %s; fallback: %s' % (
            ku.target_language(), language_name(ku.target_language()),
            engine('engine', 0), engine('fallback', 1)),
        u'API keys: %s' % u', '.join(keys),
        u'Library: %s' % ((ku.setting('library_folder') or u'add-on data folder')
                          if ku.setting_bool('save_library') else u'off'),
    ]


def colour(line):
    for marker, name in COLOURS:
        if marker in line:
            return u'[COLOR %s]%s[/COLOR]' % (name, line)
    return line


def text_for_tv():
    lines = ku.read_log(MAX_LINES)
    body = u'[CR]'.join(colour(l) for l in lines) if lines else ku.string(32177)
    return u'[B]%s[/B][CR][CR]%s' % (u'[CR]'.join(summary()), body)


def text_for_phone():
    lines = ku.read_log(MAX_LINES)
    return u'\n'.join(summary() + [u''] + (lines or [ku.string(32177)]))


def show():
    ku.textviewer(ku.string(32173), text_for_tv())


def show_on_phone():
    from . import keys, pairing, qr
    ip = ku.local_ip()
    if not ip:
        ku.notify(ku.string(32117))
        return show()
    server = pairing.LogServer(text_for_phone, title=ku.string(32173))
    url = server.start(ip)
    if not url:
        return show()
    image = ku.profile_dir('qr') + u'log-%s.png' % server.token
    ku.write_bytes(image, qr.png(qr.encode(url)))
    try:
        keys.QRWindow(ku.string(32179), image, ku.string(32180) % url).doModal()
    finally:
        server.stop()
        ku.delete(image)
    return url


def menu():
    choice = ku.select(ku.string(32173), [ku.string(32174), ku.string(32175), ku.string(32176)])
    if choice == 0:
        show()
    elif choice == 1:
        show_on_phone()
    elif choice == 2:
        ku.clear_log()
        ku.notify(ku.string(32178))
    return choice
