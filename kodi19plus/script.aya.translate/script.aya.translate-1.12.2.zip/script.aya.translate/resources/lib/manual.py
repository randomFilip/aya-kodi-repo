# -*- coding: utf-8 -*-
"""Manual mode: pick a subtitle, translate it, load it into the playing video."""
import sys

from . import core, finder, keys, kodiutils as ku
from .engines import language_name


def pick_language(source):
    if ku.setting_bool('ask_language'):
        return core.choose_language(ku.split(source)[1])
    return ku.target_language()


def main():
    args = sys.argv[1:]
    if 'settings' in args:
        ku.addon().openSettings()
        return
    if 'log' in args:
        from . import logview
        logview.menu()
        ku.addon().openSettings()
        return
    if 'import_keys' in args or 'qr' in args or 'test' in args:
        # buttons in Settings > Engines; the settings window closed itself
        # first so it can't overwrite what we save
        if 'import_keys' in args:
            keys.import_from_file()
        elif 'qr' in args:
            keys.show_qr()
        else:
            core.check_setup()
        ku.addon().openSettings()
        return

    target = ku.target_language()
    video = ku.playing_video()
    if not video:
        source = ku.browse_file(ku.string(32072), '.srt')
        language = source and pick_language(source)
        if language:
            core.run(source, target=language)
        return

    candidates = finder.find(video, target)
    first_part = ku.unstack(video)[0]
    start_folder = '' if ku.is_stream(first_part) else ku.video_folder(first_part)
    if candidates:
        labels = [c.label() for c in candidates] + [ku.string(32063)]
        heading = ku.string(32072) if ku.setting_bool('ask_language') \
            else ku.string(32064) % language_name(target)
        choice = ku.select(heading, labels)
        if choice < 0:
            return
        source = candidates[choice].path if choice < len(candidates) \
            else ku.browse_file(ku.string(32072), '.srt', start_folder)
    else:
        ku.notify(ku.string(32062))
        source = ku.browse_file(ku.string(32072), '.srt', start_folder)
    language = source and pick_language(source)
    if language:
        core.run(source, video, target=language)

