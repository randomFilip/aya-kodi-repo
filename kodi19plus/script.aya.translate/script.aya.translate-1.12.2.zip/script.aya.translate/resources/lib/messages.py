# -*- coding: utf-8 -*-
"""Status messages shown in the language the subtitles are being translated
into (so a Macedonian viewer sees Macedonian, whatever Kodi's own language).
Language names are written as the language itself and joined with an arrow,
which keeps every phrase grammatical without declension. Pure Python."""

# code: (name of the language in itself, "Translating subtitles", "done", "failed", "cancelled")
PHRASES = {
    'en': (u'English', u'Translating subtitles', u'Subtitles translated and loaded',
           u'Translation failed', u'Translation cancelled'),
    'mk': (u'македонски', u'Се преведуваат титловите', u'Титловите се преведени и вчитани',
           u'Преводот не успеа', u'Преводот е откажан'),
    'sr-latn': (u'srpski', u'Prevođenje titlova', u'Titlovi su prevedeni i učitani',
                u'Prevod nije uspeo', u'Prevod je otkazan'),
    'sr-cyrl': (u'српски', u'Превођење титлова', u'Титлови су преведени и учитани',
                u'Превод није успео', u'Превод је отказан'),
    'hr': (u'hrvatski', u'Prevođenje titlova', u'Titlovi su prevedeni i učitani',
           u'Prijevod nije uspio', u'Prijevod je otkazan'),
    'bs': (u'bosanski', u'Prevođenje titlova', u'Titlovi su prevedeni i učitani',
           u'Prijevod nije uspio', u'Prijevod je otkazan'),
    'sl': (u'slovenščina', u'Prevajanje podnapisov', u'Podnapisi so prevedeni in naloženi',
           u'Prevod ni uspel', u'Prevod je preklican'),
    'bg': (u'български', u'Превеждане на субтитрите', u'Субтитрите са преведени и заредени',
           u'Преводът не успя', u'Преводът е отменен'),
    'sq': (u'shqip', u'Po përkthehen titrat', u'Titrat u përkthyen dhe u ngarkuan',
           u'Përkthimi dështoi', u'Përkthimi u anulua'),
    'el': (u'ελληνικά', u'Μετάφραση υποτίτλων', u'Οι υπότιτλοι μεταφράστηκαν και φορτώθηκαν',
           u'Η μετάφραση απέτυχε', u'Η μετάφραση ακυρώθηκε'),
    'tr': (u'Türkçe', u'Altyazılar çevriliyor', u'Altyazılar çevrildi ve yüklendi',
           u'Çeviri başarısız oldu', u'Çeviri iptal edildi'),
    'de': (u'Deutsch', u'Untertitel werden übersetzt', u'Untertitel übersetzt und geladen',
           u'Übersetzung fehlgeschlagen', u'Übersetzung abgebrochen'),
    'fr': (u'français', u'Traduction des sous-titres', u'Sous-titres traduits et chargés',
           u'La traduction a échoué', u'Traduction annulée'),
    'it': (u'italiano', u'Traduzione dei sottotitoli', u'Sottotitoli tradotti e caricati',
           u'Traduzione non riuscita', u'Traduzione annullata'),
    'es': (u'español', u'Traduciendo subtítulos', u'Subtítulos traducidos y cargados',
           u'La traducción falló', u'Traducción cancelada'),
    'pt': (u'português', u'Traduzindo legendas', u'Legendas traduzidas e carregadas',
           u'A tradução falhou', u'Tradução cancelada'),
    'ro': (u'română', u'Se traduc subtitrările', u'Subtitrări traduse și încărcate',
           u'Traducerea a eșuat', u'Traducere anulată'),
    'ru': (u'русский', u'Перевод субтитров', u'Субтитры переведены и загружены',
           u'Не удалось перевести', u'Перевод отменён'),
    'uk': (u'українська', u'Переклад субтитрів', u'Субтитри перекладено та завантажено',
           u'Не вдалося перекласти', u'Переклад скасовано'),
    'pl': (u'polski', u'Tłumaczenie napisów', u'Napisy przetłumaczone i wczytane',
           u'Tłumaczenie nie powiodło się', u'Tłumaczenie anulowane'),
    'cs': (u'čeština', u'Překlad titulků', u'Titulky přeloženy a načteny',
           u'Překlad se nezdařil', u'Překlad zrušen'),
    'sk': (u'slovenčina', u'Preklad titulkov', u'Titulky preložené a načítané',
           u'Preklad zlyhal', u'Preklad zrušený'),
    'hu': (u'magyar', u'Feliratok fordítása', u'A feliratok lefordítva és betöltve',
           u'A fordítás sikertelen', u'Fordítás megszakítva'),
    'nl': (u'Nederlands', u'Ondertitels vertalen', u'Ondertitels vertaald en geladen',
           u'Vertalen mislukt', u'Vertalen geannuleerd'),
}
PHRASES['sr'] = PHRASES['sr-cyrl']  # plain "sr" = Google's default, Cyrillic

_KEYS = {'name': 0, 'translating': 1, 'done': 2, 'failed': 3, 'cancelled': 4}


def phrase(key, target, english_names=None):
    """Phrase in the target language; English for languages not in the table."""
    code = (target or 'en').lower()
    entry = PHRASES.get(code) or PHRASES.get(code.split('-')[0])
    if entry:
        return entry[_KEYS[key]]
    if key == 'name':
        return (english_names or {}).get(code, code)
    return PHRASES['en'][_KEYS[key]]


def heading(target, english_names=None):
    """'Се преведуваат титловите → македонски'"""
    return u'%s → %s' % (phrase('translating', target, english_names),
                               phrase('name', target, english_names))


def progress_line(done, total, activity=None, seconds=None):
    """'37% (450/1210) · Gemini 12 s': numbers only, readable in any language."""
    percent = int(100 * done / max(total, 1))
    text = u'%d%% (%d/%d)' % (percent, done, total)
    if activity:
        text += u' · %s' % activity
        if seconds is not None:
            text += u' %d s' % seconds
    return text
