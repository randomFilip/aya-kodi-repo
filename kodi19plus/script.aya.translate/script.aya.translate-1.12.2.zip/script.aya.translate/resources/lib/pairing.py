# -*- coding: utf-8 -*-
"""Send an API key from the phone to Kodi.

While the QR screen is open, AYA Translate serves one small page on the home
network: http://<Kodi's IP>:<port>/<one-time token>. The phone opens it from
the QR code, the user pastes the key and presses Save, and the key goes
straight into the add-on settings. The server stops when the screen closes
(or after 10 minutes) and only answers on the secret token's address.
Python 2/3, standard library only."""
import binascii
import os
import threading

try:  # Python 3 (Kodi 19+)
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import parse_qs
except ImportError:  # Python 2.7 (Kodi 17/18)
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import parse_qs

PY2 = str is bytes
PORTS = range(8765, 8775)
MAX_BODY = 20000
LIFETIME_SECONDS = 600


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def _escape(text):
    return (text.replace(u'&', u'&amp;').replace(u'<', u'&lt;')
            .replace(u'>', u'&gt;').replace(u'"', u'&quot;'))


class PairingServer(object):
    """`on_text(text, provider)` gets what the phone sent and returns the names
    of the keys it saved (empty list = nothing usable)."""

    def __init__(self, on_text, providers, selected=None, title=u'AYA Translate'):
        self.on_text = on_text
        self.providers = providers  # [(id, label, key page url)]
        self.selected = selected
        self.title = title
        self.token = binascii.hexlify(os.urandom(6)).decode('ascii')
        self.saved = []
        self.done = threading.Event()
        self._server = None
        self._thread = None
        self._timer = None

    # ---------------------------------------------------------- lifecycle --
    def start(self, ip):
        """Returns the URL to put in the QR code, or None if no port is free."""
        handler = self._handler()
        for port in PORTS:
            try:
                self._server = _Server(('', port), handler)
                break
            except (IOError, OSError):
                continue
        else:
            return None
        self._thread = threading.Thread(target=self._server.serve_forever, kwargs={'poll_interval': 0.5})
        self._thread.daemon = True
        self._thread.start()
        self._timer = threading.Timer(LIFETIME_SECONDS, self.done.set)
        self._timer.daemon = True
        self._timer.start()
        return u'http://%s:%d/%s' % (ip, self._server.server_address[1], self.token)

    def stop(self):
        if self._timer:
            self._timer.cancel()
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            self._server = None

    # -------------------------------------------------------------- pages --
    def page(self, message=u'', error=False):
        links = u''.join(u'<li><a href="%s" target="_blank" rel="noopener">%s</a></li>'
                         % (_escape(url), _escape(label)) for _, label, url in self.providers)
        options = u''.join(u'<option value="%s"%s>%s</option>' % (
            _escape(pid), u' selected' if pid == self.selected else u'', _escape(label))
            for pid, label, _ in self.providers)
        note = (u'<p class="%s">%s</p>' % ('err' if error else 'ok', _escape(message))) if message else u''
        return PAGE % {'title': _escape(self.title), 'links': links, 'options': options,
                       'note': note, 'action': u'/%s' % self.token}

    def done_page(self, names):
        return DONE_PAGE % {'title': _escape(self.title), 'names': _escape(u', '.join(names))}

    def _handler(self):
        pairing = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):  # keep kodi.log clean
                pass

            def _send(self, status, body):
                data = body.encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(data)

            def _ours(self):
                return self.path.split('?')[0].rstrip('/') == '/' + pairing.token

            def do_GET(self):
                if not self._ours():
                    return self._send(404, u'Not found')
                self._send(200, pairing.page())

            def do_POST(self):
                if not self._ours() or isinstance(pairing, LogServer):
                    return self._send(404, u'Not found')
                try:
                    length = int(self.headers.get('Content-Length') or 0)
                except ValueError:
                    length = 0
                if length <= 0 or length > MAX_BODY:
                    return self._send(400, pairing.page(u'Nothing received, try again.', True))
                raw = self.rfile.read(length)
                fields = parse_qs(raw if PY2 else raw.decode('utf-8', 'replace'))

                def field(name):
                    value = (fields.get(name) or [b'' if PY2 else u''])[0]
                    return value.decode('utf-8', 'replace') if isinstance(value, bytes) else value

                names = pairing.on_text(field('keys'), field('provider'))
                if not names:
                    return self._send(200, pairing.page(
                        u'No key recognised. Paste the whole key (or lines like gemini=KEY).', True))
                pairing.saved = names
                self._send(200, pairing.done_page(names))
                pairing.done.set()

        return Handler


class LogServer(PairingServer):
    """Same one-time page on the home network, showing AYA's log so it can be
    copied or shared from the phone. Read only: nothing can be sent back."""

    def __init__(self, text, title=u'AYA Translate log'):
        PairingServer.__init__(self, lambda *args: [], [], title=title)
        self.text = text  # function returning the current log text

    def page(self, message=u'', error=False):
        return LOG_PAGE % {'title': _escape(self.title), 'log': _escape(self.text())}


LOG_PAGE = u'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>%(title)s</title>
<style>body{font-family:system-ui,sans-serif;background:#0e131f;color:#e6ebf5;margin:0;padding:16px}
pre{white-space:pre-wrap;word-break:break-word;font-size:12px;background:#1c2436;padding:10px;border-radius:8px}
button{width:100%%;padding:14px;font-size:1.1em;border:0;border-radius:8px;background:#4285f4;color:#fff}
small{color:#aab4c8}</style></head><body>
<h1 style="font-size:1.3em">%(title)s</h1>
<button onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById('log').innerText).then(function(){this.textContent='Copied';}.bind(this))">Copy the log</button>
<p><small>API keys are never written to this log. Paste it in a message when you ask for help.</small></p>
<pre id="log">%(log)s</pre>
</body></html>
'''


PAGE = u'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%(title)s</title>
<style>
body{font-family:system-ui,sans-serif;background:#0e131f;color:#e6ebf5;margin:0;padding:20px;line-height:1.45}
h1{font-size:1.4em;margin:0 0 12px}a{color:#7fb0ff}
ol{padding-left:1.2em}textarea{width:100%%;box-sizing:border-box;min-height:7em;font:16px monospace;
padding:10px;border-radius:8px;border:1px solid #3a4560;background:#1c2436;color:#fff}
select{font-size:1em;padding:6px;margin:6px 0 10px;border-radius:6px}
button{width:100%%;padding:14px;margin-top:12px;font-size:1.1em;border:0;border-radius:8px;background:#4285f4;color:#fff}
.ok{color:#7ddc8a}.err{color:#ff8a80}small{color:#aab4c8}
</style></head><body>
<h1>%(title)s: add an API key</h1>
<ol>
<li>Get a free key (opens in a new tab), then come back here:<ul>%(links)s</ul></li>
<li>Copy the key and paste it below, and choose which service it is for.</li>
<li>Press <b>Save to Kodi</b>.</li>
</ol>
%(note)s
<form method="post" action="%(action)s">
<label>This key is for: <select name="provider">%(options)s</select></label>
<textarea name="keys" placeholder="Paste your key here" autocapitalize="off" autocomplete="off" spellcheck="false"></textarea>
<button type="submit">Save to Kodi</button>
</form>
<p><small>You can paste several keys at once, one per line (gemini=..., groq=...).
The key goes only to your Kodi on your home network.</small></p>
</body></html>
'''

DONE_PAGE = u'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>%(title)s</title>
<style>body{font-family:system-ui,sans-serif;background:#0e131f;color:#e6ebf5;padding:20px;text-align:center}
h1{color:#7ddc8a}</style></head><body>
<h1>&#10003; Saved</h1><p>%(names)s key saved in Kodi.<br>You can close this page.</p>
</body></html>
'''
