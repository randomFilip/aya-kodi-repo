# -*- coding: utf-8 -*-
"""Minimal QR code generator (byte mode, error correction M, versions 1-10)
and PNG writer. Pure Python 2/3 with no dependencies, because Kodi has no QR
library and the pairing address (Kodi's own IP and a one-time token) is only
known on the device. Follows ISO/IEC 18004; structure after Project Nayuki's
reference implementation (MIT)."""
import struct
import zlib

MAX_VERSION = 10
# Error correction level M: format bits 0, table row 1
FORMAT_BITS_M = 0
ECC_CODEWORDS_PER_BLOCK_M = (-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26)
NUM_BLOCKS_M = (-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5)
PAD_BYTES = (0xEC, 0x11)


def _bit(value, index):
    return (value >> index) & 1 != 0


def _raw_data_modules(version):
    result = (16 * version + 128) * version + 64
    if version >= 2:
        count = version // 7 + 2
        result -= (25 * count - 10) * count - 55
        if version >= 7:
            result -= 36
    return result


def _data_codewords(version):
    return (_raw_data_modules(version) // 8
            - ECC_CODEWORDS_PER_BLOCK_M[version] * NUM_BLOCKS_M[version])


def _rs_multiply(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _rs_multiply(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _rs_multiply(root, 0x02)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for byte in data:
        factor = byte ^ result.pop(0)
        result.append(0)
        for i, coefficient in enumerate(divisor):
            result[i] ^= _rs_multiply(coefficient, factor)
    return result


def _codewords(data, version):
    """Byte-mode segment + terminator + padding, then interleaved ECC."""
    bits = []

    def put(value, length):
        bits.extend((value >> i) & 1 for i in reversed(range(length)))

    put(0x4, 4)                                    # byte mode
    put(len(data), 8 if version <= 9 else 16)      # character count
    for byte in data:
        put(byte, 8)
    capacity = _data_codewords(version) * 8
    put(0, min(4, capacity - len(bits)))           # terminator
    put(0, (-len(bits)) % 8)
    words = [int(''.join(str(b) for b in bits[i:i + 8]), 2) for i in range(0, len(bits), 8)]
    i = 0
    while len(words) < capacity // 8:
        words.append(PAD_BYTES[i % 2])
        i += 1

    blocks_count = NUM_BLOCKS_M[version]
    ecc_len = ECC_CODEWORDS_PER_BLOCK_M[version]
    raw = _raw_data_modules(version) // 8
    short_blocks = blocks_count - raw % blocks_count
    short_len = raw // blocks_count
    divisor = _rs_divisor(ecc_len)
    blocks, k = [], 0
    for i in range(blocks_count):
        chunk = words[k:k + short_len - ecc_len + (0 if i < short_blocks else 1)]
        k += len(chunk)
        ecc = _rs_remainder(chunk, divisor)
        if i < short_blocks:
            chunk.append(0)
        blocks.append(chunk + ecc)
    result = []
    for i in range(len(blocks[0])):
        for j, block in enumerate(blocks):
            if i != short_len - ecc_len or j >= short_blocks:
                result.append(block[i])
    return result


class _Matrix(object):
    def __init__(self, version):
        self.version = version
        self.size = version * 4 + 17
        self.modules = [[False] * self.size for _ in range(self.size)]
        self.function = [[False] * self.size for _ in range(self.size)]

    def set_function(self, x, y, dark):
        self.modules[y][x] = dark
        self.function[y][x] = True

    def draw_function_patterns(self):
        size = self.size
        for i in range(size):
            self.set_function(6, i, i % 2 == 0)
            self.set_function(i, 6, i % 2 == 0)
        for x, y in ((3, 3), (size - 4, 3), (3, size - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < size and 0 <= yy < size:
                        self.set_function(xx, yy, max(abs(dx), abs(dy)) not in (2, 4))
        positions = self.alignment_positions()
        count = len(positions)
        for i in range(count):
            for j in range(count):
                if (i == 0 and j == 0) or (i == 0 and j == count - 1) or (i == count - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.set_function(positions[i] + dx, positions[j] + dy,
                                          max(abs(dx), abs(dy)) != 1)
        self.draw_format_bits(0)  # placeholder, redrawn with the chosen mask
        if self.version >= 7:
            remainder = self.version
            for _ in range(12):
                remainder = (remainder << 1) ^ ((remainder >> 11) * 0x1F25)
            bits = self.version << 12 | remainder
            for i in range(18):
                bit = _bit(bits, i)
                a, b = size - 11 + i % 3, i // 3
                self.set_function(a, b, bit)
                self.set_function(b, a, bit)

    def alignment_positions(self):
        if self.version == 1:
            return []
        count = self.version // 7 + 2
        step = (self.version * 8 + count * 3 + 5) // (count * 4 - 4) * 2
        result = [self.size - 7 - i * step for i in range(count - 1)] + [6]
        return list(reversed(result))

    def draw_format_bits(self, mask):
        data = FORMAT_BITS_M << 3 | mask
        remainder = data
        for _ in range(10):
            remainder = (remainder << 1) ^ ((remainder >> 9) * 0x537)
        bits = (data << 10 | remainder) ^ 0x5412
        size = self.size
        for i in range(0, 6):
            self.set_function(8, i, _bit(bits, i))
        self.set_function(8, 7, _bit(bits, 6))
        self.set_function(8, 8, _bit(bits, 7))
        self.set_function(7, 8, _bit(bits, 8))
        for i in range(9, 15):
            self.set_function(14 - i, 8, _bit(bits, i))
        for i in range(0, 8):
            self.set_function(size - 1 - i, 8, _bit(bits, i))
        for i in range(8, 15):
            self.set_function(8, size - 15 + i, _bit(bits, i))
        self.set_function(8, size - 8, True)  # always dark

    def draw_codewords(self, words):
        i, total = 0, len(words) * 8
        right = self.size - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vertical in range(self.size):
                for j in range(2):
                    x = right - j
                    upward = (right + 1) & 2 == 0
                    y = self.size - 1 - vertical if upward else vertical
                    if not self.function[y][x] and i < total:
                        self.modules[y][x] = _bit(words[i >> 3], 7 - (i & 7))
                        i += 1
            right -= 2

    def apply_mask(self, mask):
        test = MASKS[mask]
        for y in range(self.size):
            for x in range(self.size):
                if not self.function[y][x] and test(x, y):
                    self.modules[y][x] = not self.modules[y][x]

    def penalty(self):
        """Rules 1, 2 and 4 of the standard (enough to pick a readable mask)."""
        size, modules, score = self.size, self.modules, 0
        for lines in (modules, list(zip(*modules))):
            for line in lines:
                run, previous = 0, None
                for dark in line:
                    if dark == previous:
                        run += 1
                        if run == 5:
                            score += 3
                        elif run > 5:
                            score += 1
                    else:
                        run, previous = 1, dark
        for y in range(size - 1):
            for x in range(size - 1):
                colour = modules[y][x]
                if colour == modules[y][x + 1] == modules[y + 1][x] == modules[y + 1][x + 1]:
                    score += 3
        dark = sum(sum(1 for m in row if m) for row in modules)
        total = size * size
        score += abs(dark * 20 - total * 10) // total * 10
        return score


MASKS = (
    lambda x, y: (x + y) % 2 == 0,
    lambda x, y: y % 2 == 0,
    lambda x, y: x % 3 == 0,
    lambda x, y: (x + y) % 3 == 0,
    lambda x, y: (x // 3 + y // 2) % 2 == 0,
    lambda x, y: x * y % 2 + x * y % 3 == 0,
    lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
    lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
)


def encode(text):
    """Text -> square list of rows of booleans (True = dark)."""
    data = bytearray(text.encode('utf-8') if not isinstance(text, bytes) else text)
    for version in range(1, MAX_VERSION + 1):
        header_bits = 4 + (8 if version <= 9 else 16)
        if header_bits + len(data) * 8 <= _data_codewords(version) * 8:
            break
    else:
        raise ValueError('Text too long for a QR code: %d bytes' % len(data))
    words = _codewords(data, version)
    best, best_score = None, None
    for mask in range(8):
        matrix = _Matrix(version)
        matrix.draw_function_patterns()
        matrix.draw_codewords(words)
        matrix.apply_mask(mask)
        matrix.draw_format_bits(mask)
        score = matrix.penalty()
        if best_score is None or score < best_score:
            best, best_score = matrix, score
    return best.modules


def png(modules, scale=10, border=4):
    """Black-on-white 8-bit greyscale PNG of a QR matrix."""
    size = len(modules)
    dimension = (size + 2 * border) * scale
    rows = []
    for y in range(dimension):
        my = y // scale - border
        row = bytearray([0])  # filter type: none
        for x in range(dimension):
            mx = x // scale - border
            dark = 0 <= mx < size and 0 <= my < size and modules[my][mx]
            row.append(0 if dark else 255)
        rows.append(bytes(row))

    def chunk(tag, data):
        return (struct.pack('>I', len(data)) + tag + data
                + struct.pack('>I', zlib.crc32(tag + data) & 0xFFFFFFFF))

    header = struct.pack('>IIBBBBB', dimension, dimension, 8, 0, 0, 0, 0)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header)
            + chunk(b'IDAT', zlib.compress(b''.join(rows), 9)) + chunk(b'IEND', b''))
