# -*- coding: utf-8 -*-
"""Minimal SRT reader/writer. Pure Python (no Kodi imports) so it can be unit-tested."""
import codecs
import re

_TIME = re.compile(r'(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})')
_TIMING_LINE = re.compile(
    r'^\s*(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})(.*)$')


class Cue(object):
    __slots__ = ('start', 'end', 'text', 'extra')

    def __init__(self, start, end, text, extra=''):
        self.start = start  # milliseconds
        self.end = end
        self.text = text    # may contain '\n' and formatting tags
        self.extra = extra  # anything after the timing (e.g. X1:.. positions)

    def __repr__(self):
        return 'Cue(%d, %d, %r)' % (self.start, self.end, self.text)


def to_ms(stamp):
    h, m, s, ms = _TIME.match(stamp).groups()
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int(ms.ljust(3, '0'))


def from_ms(ms):
    ms = max(0, int(ms))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return '%02d:%02d:%02d,%03d' % (h, m, s, ms)


def decode(data, fallback='cp1252'):
    """Bytes -> text. UTF-8/UTF-16 are detected, old Cyrillic (cp1251) files are
    recognised, anything else uses `fallback` (cp1250 Central European, cp1252 Western)."""
    data = bytes(data)
    if data.startswith(codecs.BOM_UTF8):
        return data[3:].decode('utf-8', 'replace')
    if data[:2] in (codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE):
        return data.decode('utf-16', 'replace')
    try:
        return data.decode('utf-8')
    except UnicodeDecodeError:
        pass
    fallback = (fallback or 'cp1250').lower()
    if fallback in LATIN_CODEPAGES and _looks_cyrillic_8bit(data):
        return data.decode('cp1251', 'replace')
    try:
        return data.decode(fallback)
    except (UnicodeDecodeError, LookupError):
        return data.decode('latin-1')


LATIN_CODEPAGES = ('cp1250', 'cp1252', 'windows-1250', 'windows-1252', 'latin-1', 'latin1',
                   'latin2', 'iso-8859-1', 'iso-8859-2', 'iso8859-1', 'iso8859-2')


def _looks_cyrillic_8bit(data):
    """cp1251 (Cyrillic) text is mostly bytes >= 0xC0; Latin-script text in
    cp1250/cp1252 is mostly plain ASCII letters with a few accented ones."""
    data = bytearray(data)  # iterate integers on Python 2 and 3
    high = sum(1 for b in data if b >= 0xC0)
    ascii_letters = sum(1 for b in data if 65 <= b <= 90 or 97 <= b <= 122)
    return high > 0.4 * (high + ascii_letters)


def parse(text):
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    cues = []
    body = None
    for i, line in enumerate(lines):
        match = _TIMING_LINE.match(line)
        if match:
            body = []
            cues.append((Cue(to_ms(match.group(1)), to_ms(match.group(2)), '',
                             match.group(3).strip()), body))
            continue
        if body is None:
            continue
        # skip the numeric index line that belongs to the next cue
        if line.strip().isdigit() and i + 1 < len(lines) and _TIMING_LINE.match(lines[i + 1]):
            continue
        body.append(line)
    result = []
    for cue, body in cues:
        cue.text = u'\n'.join(l.rstrip() for l in body if l.strip())
        result.append(cue)
    return result


def compose(cues):
    blocks = []
    for number, cue in enumerate(cues, 1):
        timing = u'%s --> %s' % (from_ms(cue.start), from_ms(cue.end))
        if cue.extra:
            timing += u' ' + cue.extra
        blocks.append(u'%d\n%s\n%s\n' % (number, timing, cue.text))
    return u'\n'.join(blocks)
