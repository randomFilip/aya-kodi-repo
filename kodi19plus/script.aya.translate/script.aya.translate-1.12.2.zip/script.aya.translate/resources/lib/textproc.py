# -*- coding: utf-8 -*-
"""Text handling around translation: strip/restore tags, keep dialogue speakers
apart, join sentences split across cues and split translations back.
Pure Python (no Kodi imports)."""
import re

_TAG = re.compile(r'<[^>]*>|\{[^}]*\}')
_LEADING_ASS = re.compile(r'^(?:\{\\[^}]*\})+')
_LETTER = re.compile(r'[^\W\d_]', re.UNICODE)
_SENTENCE_END = re.compile(u'[.!?…♪]["\'»”)\\]]*$')
_ELLIPSIS = ('...', u'…')
_DASHES = u'-–—'


class Template(object):
    """What we need to rebuild a cue after its text was translated."""
    __slots__ = ('ass', 'italic', 'dialog')

    def __init__(self, ass='', italic=False, dialog=False):
        self.ass = ass
        self.italic = italic
        self.dialog = dialog


def disassemble(text):
    """Cue text -> (Template, [plain text units]).

    A normal cue becomes one unit (its lines joined, so the translator sees
    one sentence). A dialogue cue ("- Hi.\\n- Hello.") becomes one unit per
    speaker so the two speakers are never mixed together."""
    match = _LEADING_ASS.match(text)
    ass = match.group(0) if match else ''
    italic = '<i>' in text.lower()
    clean = _TAG.sub('', text)
    lines = [re.sub(r'\s+', ' ', l).strip() for l in clean.split('\n')]
    lines = [l for l in lines if l]
    if len(lines) > 1 and all(l[0] in _DASHES for l in lines):
        return Template(ass, italic, True), [l.lstrip(_DASHES).strip() for l in lines]
    return Template(ass, italic, False), ([' '.join(lines)] if lines else [])


def assemble(template, units, width=42):
    units = [u.strip() for u in units if u and u.strip()]
    if not units:
        return ''
    if template.dialog and len(units) > 1:
        lines = ['- ' + u for u in units]
    else:
        lines = wrap(' '.join(units), width)
    body = '\n'.join(lines)
    if template.italic:
        body = '<i>%s</i>' % body
    return template.ass + body


def wrap(text, width=42):
    """Break long text into two lines at the space closest to the middle."""
    text = text.strip()
    if len(text) <= width or ' ' not in text:
        return [text]
    middle = len(text) // 2
    spaces = [p for p in (text.rfind(' ', 0, middle + 1), text.find(' ', middle)) if p > 0]
    cut = min(spaces, key=lambda p: abs(p - middle))
    return [text[:cut].strip(), text[cut + 1:].strip()]


def match_capital(source, translated):
    """Some engines (Google into Serbian) drop the capital at the start of a line."""
    first_source = _LETTER.search(source)
    first_out = _LETTER.search(translated)
    if first_source and first_out and first_source.group(0).isupper() \
            and first_out.group(0).islower():
        i = first_out.start()
        return translated[:i] + translated[i].upper() + translated[i + 1:]
    return translated


def needs_translation(text):
    """Skip units with no letters at all (music notes, '...', numbers)."""
    return bool(_LETTER.search(text))


def ends_sentence(text):
    return bool(_SENTENCE_END.search(text.strip()))


def continues(prev, nxt):
    """Does the text `nxt` continue the sentence started in `prev`?"""
    prev, nxt = prev.rstrip(), nxt.lstrip()
    if prev.endswith(_ELLIPSIS):
        # "I think..." / "...we should go."  or  "I think..." / "we should go."
        return nxt.startswith(_ELLIPSIS) or nxt[:1].islower()
    return not ends_sentence(prev)


def group_sentences(units, max_units=4, max_gap_ms=2000):
    """Group consecutive units (objects with .text .start .end .dialog .cue)
    that form one sentence, so it can be translated as a whole."""
    groups = []
    for unit in units:
        if groups:
            group = groups[-1]
            prev = group[-1]
            if (len(group) < max_units and not prev.dialog and not unit.dialog
                    and prev.cue != unit.cue
                    and unit.start - prev.end <= max_gap_ms
                    and continues(prev.text, unit.text)):
                group.append(unit)
                continue
        groups.append([unit])
    return groups


def join_units(texts):
    """Join the parts of a split sentence, removing '...' at the joints."""
    out = texts[0]
    for nxt in texts[1:]:
        left = out.rstrip()
        right = nxt.lstrip()
        if left.endswith(_ELLIPSIS) and (right.startswith(_ELLIPSIS) or right[:1].islower()):
            left = left.rstrip('.').rstrip(u'…').rstrip()
            right = right.lstrip('.').lstrip(u'…').lstrip()
        out = left + ' ' + right
    return out


def split_proportional(text, weights):
    """Split a translated sentence back over len(weights) cues, giving each cue
    a share of words proportional to its original length."""
    count = len(weights)
    words = text.split()
    if count <= 1:
        return [' '.join(words)]
    if len(words) <= count:
        return words + [''] * (count - len(words))
    total_weight = float(sum(weights)) or count
    total_chars = len(' '.join(words))
    parts, index, pos, cumulative = [], 0, 0, 0
    for k in range(count - 1):
        cumulative += weights[k]
        target = total_chars * cumulative / total_weight
        reserve = count - 1 - k  # leave at least one word for each later part
        part = []
        while index < len(words) - reserve:
            word = words[index]
            if part and pos + len(word) / 2.0 > target:
                break
            part.append(word)
            pos += len(word) + 1
            index += 1
        parts.append(' '.join(part))
    parts.append(' '.join(words[index:]))
    return parts
