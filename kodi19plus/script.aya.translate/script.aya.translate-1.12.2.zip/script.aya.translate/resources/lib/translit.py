# -*- coding: utf-8 -*-
"""Serbian Cyrillic <-> Latin conversion (the official one-to-one alphabet
mapping). Formatting tags are left untouched. Pure Python (no Kodi imports)."""
import re

_CYR_TO_LAT = {
    u'А': u'A', u'Б': u'B', u'В': u'V', u'Г': u'G', u'Д': u'D', u'Ђ': u'Đ', u'Е': u'E',
    u'Ж': u'Ž', u'З': u'Z', u'И': u'I', u'Ј': u'J', u'К': u'K', u'Л': u'L', u'Љ': u'Lj',
    u'М': u'M', u'Н': u'N', u'Њ': u'Nj', u'О': u'O', u'П': u'P', u'Р': u'R', u'С': u'S',
    u'Т': u'T', u'Ћ': u'Ć', u'У': u'U', u'Ф': u'F', u'Х': u'H', u'Ц': u'C', u'Ч': u'Č',
    u'Џ': u'Dž', u'Ш': u'Š',
}
_CYR_TO_LAT.update(dict((c.lower(), l.lower()) for c, l in list(_CYR_TO_LAT.items())))
_LAT_TO_CYR = dict((l, c) for c, l in _CYR_TO_LAT.items() if len(l) == 1)
_DIGRAPHS = {u'lj': u'љ', u'nj': u'њ', u'dž': u'џ'}
# words where "dž" is two letters (prefix nad-/pod- + ž...): nadživeti = надживети
_SPLIT_DZ_PREFIXES = (u'nadž', u'podž')

_TAG = re.compile(r'(<[^>]*>|\{[^}]*\})')
_CYRILLIC = re.compile(u'[Ѐ-ӿ]')
_LATIN = re.compile(u'[A-Za-zČčĆćŽžŠšĐđ]')
_WORD = re.compile(r'[^\W\d_]+', re.UNICODE)
_FOREIGN = re.compile(u'[qwxyQWXY]')  # not in the Serbian alphabet: leave the word alone


def dominant_script(text):
    cyrillic = len(_CYRILLIC.findall(text))
    latin = len(_LATIN.findall(text))
    if not cyrillic and not latin:
        return None
    return 'cyrl' if cyrillic > latin else 'latn'


def _outside_tags(text, convert):
    parts = _TAG.split(text)
    return u''.join(part if i % 2 else convert(part) for i, part in enumerate(parts))


def _cyr_to_lat(text):
    out = []
    for i, char in enumerate(text):
        latin = _CYR_TO_LAT.get(char)
        if latin is None:
            out.append(char)
            continue
        if len(latin) == 2 and char.isupper():
            following = text[i + 1:i + 2]
            previous = text[i - 1:i] if i else u''
            # ЉУБАВ -> LJUBAV, Љубав -> Ljubav
            if following.isupper() or (previous.isupper() and not following.islower()):
                latin = latin.upper()
        out.append(latin)
    return u''.join(out)


def _lat_word_to_cyr(match):
    word = match.group(0)
    if _FOREIGN.search(word) or _CYRILLIC.search(word):
        return word
    lower = word.lower()
    out, i = [], 0
    while i < len(word):
        pair = lower[i:i + 2]
        if pair in _DIGRAPHS and not (pair == u'dž' and lower.startswith(_SPLIT_DZ_PREFIXES)
                                      and i == 2):
            cyr = _DIGRAPHS[pair]
            out.append(cyr.upper() if word[i].isupper() else cyr)
            i += 2
            continue
        out.append(_LAT_TO_CYR.get(word[i], word[i]))
        i += 1
    return u''.join(out)


def to_latin(text):
    return _outside_tags(text, _cyr_to_lat)


def to_cyrillic(text):
    """Only converts text that has no Cyrillic yet (the engine answered in Latin)."""
    def convert(part):
        return part if _CYRILLIC.search(part) else _WORD.sub(_lat_word_to_cyr, part)
    return _outside_tags(text, convert)


def convert_cues(cues, script):
    """script: 'latn' or 'cyrl'. Changes the cues in place and returns them."""
    convert = to_latin if script == 'latn' else to_cyrillic
    for cue in cues:
        cue.text = convert(cue.text)
    return cues
