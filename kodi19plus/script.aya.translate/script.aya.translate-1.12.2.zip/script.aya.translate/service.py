# -*- coding: utf-8 -*-
"""AYA Translate, background service (translates newly downloaded subtitles)."""
from resources.lib.service import Service

Service().run()
