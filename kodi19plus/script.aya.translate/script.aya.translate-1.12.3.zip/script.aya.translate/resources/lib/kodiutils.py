# -*- coding: utf-8 -*-
"""Everything that touches the Kodi API goes through here, so the differences
between Kodi versions live in one file:

* Kodi 17 Krypton / 18 Leia: Python 2.7, the API returns UTF-8 byte strings,
  xbmc.translatePath, File.read() (no readBytes on 17), LOGNOTICE.
* Kodi 19 Matrix / 20 Nexus / 21 Omega and later: Python 3,
  xbmcvfs.translatePath, File.readBytes(), LOGINFO.
"""
import io
import json
import os
import re
import sys
import threading
import time

try:  # Python 3
    from urllib.parse import unquote, urlsplit
    from urllib.request import ProxyHandler, build_opener
except ImportError:  # Python 2.7 (Kodi 17/18)
    from urllib import unquote
    from urlparse import urlsplit
    from urllib2 import ProxyHandler, build_opener

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

PY2 = sys.version_info[0] == 2
ADDON_ID = 'script.aya.translate'
STREAM_PREFIXES = ('http://', 'https://', 'plugin://', 'pvr://', 'upnp://', 'rtmp://',
                   'rtsp://', 'udp://', 'mms://')
# Before Kodi 19, LOGINFO only shows up with debug logging enabled.
LOG_INFO = getattr(xbmc, 'LOGNOTICE', xbmc.LOGINFO)


# ---------------------------------------------------------------- text --
def to_text(value):
    """Kodi (Python 2) returns UTF-8 byte strings: make everything unicode."""
    if PY2 and isinstance(value, str):
        return value.decode('utf-8', 'replace')
    return value


def to_kodi(value):
    """What we hand to the Kodi API: UTF-8 bytes on Python 2, str on Python 3."""
    if PY2 and isinstance(value, unicode):  # noqa: F821  pylint: disable=undefined-variable
        return value.encode('utf-8')
    return value


# ------------------------------------------------------------ settings --
def addon():
    # A fresh instance always sees the latest saved settings.
    return xbmcaddon.Addon(ADDON_ID)


def addon_info(key):
    return to_text(addon().getAddonInfo(key))


def setting(setting_id):
    return to_text(addon().getSetting(setting_id)).strip()


def setting_bool(setting_id):
    return setting(setting_id).lower() == 'true'


def setting_int(setting_id, default=0):
    try:
        return int(float(setting(setting_id)))
    except ValueError:
        return default


def string(string_id):
    return to_text(addon().getLocalizedString(string_id))


# ------------------------------------------------------------- logging --
LOG_NAME = 'aya.log'
LOG_FILE_MAX = 256 * 1024  # then aya.log -> aya.log.1
_log_lock = threading.Lock()
# Anything that looks like an API key is hidden before it is written anywhere.
_SECRETS = (
    (re.compile(r'AIza[0-9A-Za-z_\-]{8,}'), u'AIza...(hidden)'),
    (re.compile(r'gsk_[0-9A-Za-z]{6,}'), u'gsk_...(hidden)'),
    (re.compile(r'sk-or-[0-9A-Za-z_\-]{6,}'), u'sk-or-...(hidden)'),
    (re.compile(r'sk-[0-9A-Za-z_\-]{16,}'), u'sk-...(hidden)'),
    (re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}(:fx)?'),
     u'(hidden key)'),
    (re.compile(r'(Bearer|DeepL-Auth-Key)\s+\S+'), u'\\1 (hidden)'),
    (re.compile(r'([?&](?:key|api_key|token)=)[^&\s]+'), u'\\1(hidden)'),
)


def redact(text):
    for pattern, replacement in _SECRETS:
        text = pattern.sub(replacement, text)
    return text


def log_path():
    return os.path.join(translate_path(addon_info('profile')), LOG_NAME)


def _level_name(level):
    if level == xbmc.LOGERROR:
        return u'ERROR'
    if level == xbmc.LOGWARNING:
        return u'WARNING'
    if level == xbmc.LOGDEBUG:
        return u'DEBUG'
    return u'INFO'


def _write_log_file(level, message):
    """AYA's own log, in the add-on data folder. Never raises."""
    try:
        path = log_path()
        with _log_lock:
            folder = os.path.dirname(path)
            if not os.path.isdir(folder):
                os.makedirs(folder)
            if os.path.exists(path) and os.path.getsize(path) > LOG_FILE_MAX:
                old = path + '.1'
                if os.path.exists(old):
                    os.remove(old)
                os.rename(path, old)
            with io.open(path, 'a', encoding='utf-8') as handle:
                handle.write(u'%s %-7s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'),
                                                 _level_name(level), message))
    except Exception:  # pylint: disable=broad-except  # logging must never break anything
        pass


def log(message, level=None):
    level = LOG_INFO if level is None else level
    message = redact(to_text(message))
    xbmc.log(to_kodi(u'[%s] %s' % (ADDON_ID, message)), level)
    _write_log_file(level, message)


def read_log(max_lines=400):
    """Last lines of aya.log (and aya.log.1 when aya.log is short)."""
    lines = []
    for path in (log_path() + '.1', log_path()):
        try:
            with io.open(path, encoding='utf-8', errors='replace') as handle:
                lines.extend(handle.read().splitlines())
        except (IOError, OSError):
            continue
    return lines[-max_lines:]


def clear_log():
    for path in (log_path(), log_path() + '.1'):
        try:
            os.remove(path)
        except OSError:
            pass


def notify(message, milliseconds=5000, heading=None, sound=True):
    dialog = xbmcgui.Dialog()
    args = (to_kodi(heading or addon_info('name')), to_kodi(message),
            to_kodi(addon_info('icon')), milliseconds)
    try:
        dialog.notification(*(args + (sound,)))
    except TypeError:  # Kodi without the sound argument
        dialog.notification(*args)


def fullscreen_video():
    return bool(xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)'))


# ---------------------------------------------------------------- dialogs --
def select(heading, labels):
    return xbmcgui.Dialog().select(to_kodi(heading), [to_kodi(l) for l in labels])


def ok(heading, message):
    xbmcgui.Dialog().ok(to_kodi(heading), to_kodi(message))


def textviewer(heading, text):
    dialog = xbmcgui.Dialog()
    if hasattr(dialog, 'textviewer'):  # Kodi 16+
        dialog.textviewer(to_kodi(heading), to_kodi(text))
    else:
        dialog.ok(to_kodi(heading), to_kodi(text))


def yesno(heading, message, autoclose_ms=0):
    dialog = xbmcgui.Dialog()
    try:
        return dialog.yesno(to_kodi(heading), to_kodi(message), autoclose=autoclose_ms)
    except TypeError:  # Kodi without the autoclose argument
        return dialog.yesno(to_kodi(heading), to_kodi(message))


def browse_file(heading, mask, start_folder=''):
    path = to_text(xbmcgui.Dialog().browse(1, to_kodi(heading), 'files', to_kodi(mask),
                                           False, False, to_kodi(start_folder)))
    return path if path and path != start_folder else None


class Progress(object):
    """Shows translation progress: a corner box while a video plays (doesn't
    block watching), a cancellable dialog otherwise.

    The text is '37% (450/1210) · Gemini 12 s'; the seconds tick every second
    while the engine works on a batch, so the user sees it hasn't frozen.

    Kodi's skins slide the corner box out of view during full-screen video, so
    then the progress is also shown as a silent notification every few seconds."""

    TOAST_EVERY = 8  # seconds; notifications queue up if sent faster than they show

    def __init__(self, heading, background):
        from .messages import progress_line
        self._line = progress_line
        self.heading = to_kodi(heading)
        self.background = background
        self.monitor = xbmc.Monitor()
        self.done, self.total = 0, 0
        self.activity, self.since = None, None
        self.last_toast = 0
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.dialog = xbmcgui.DialogProgressBG() if background else xbmcgui.DialogProgress()
        self.dialog.create(self.heading, to_kodi(progress_line(0, 1)))
        self._ticker = threading.Thread(target=self._tick)
        self._ticker.daemon = True
        self._ticker.start()

    def update(self, done, total):
        with self._lock:
            self.done, self.total = done, total
        self._render()

    def working(self, activity, total=None):
        """An engine started on the next batch."""
        with self._lock:
            self.activity, self.since = activity, time.time()
            if total:
                self.total = total
        self._render()

    def _tick(self):
        while not self._stop.wait(1.0):
            self._render()

    def _render(self):
        with self._lock:
            seconds = int(time.time() - self.since) if self.since else None
            message = to_kodi(self._line(self.done, max(self.total, 1), self.activity, seconds))
            percent = int(100 * self.done / max(self.total, 1))
            try:
                if self.background:
                    self.dialog.update(percent, self.heading, message)
                else:
                    # update(percent, message) works on 17/18 (as line1) and 19+ (message)
                    self.dialog.update(percent, message)
            except Exception:  # pylint: disable=broad-except  # dialog already closed
                pass
            toast = (self.background and not self._stop.is_set()
                     and time.time() - self.last_toast >= self.TOAST_EVERY and fullscreen_video())
            if toast:
                self.last_toast = time.time()
        if toast:
            notify(to_text(message), (self.TOAST_EVERY - 1) * 1000, heading=to_text(self.heading),
                   sound=False)

    def cancelled(self):
        if self.monitor.abortRequested():
            return True
        return not self.background and self.dialog.iscanceled()

    def close(self):
        self._stop.set()
        self._ticker.join(2)
        with self._lock:
            self.dialog.close()


# --------------------------------------------------------------- player --
def playing_video():
    """Path of the playing video or None."""
    player = xbmc.Player()
    try:
        return to_text(player.getPlayingFile()) if player.isPlayingVideo() else None
    except RuntimeError:  # playback stopped between the two calls
        return None


def video_info():
    """Title, year, IMDb id, show/season/episode of the playing video (what
    Kodi's library or the add-on that started it knows); {} when nothing plays."""
    try:
        tag = xbmc.Player().getVideoInfoTag()
    except (RuntimeError, AttributeError):
        return {}

    def get(name, *args):
        method = getattr(tag, name, None)
        try:
            return method(*args) if method else None
        except Exception:  # pylint: disable=broad-except
            return None

    info = {'title': to_text(get('getTitle') or u''),
            'original_title': to_text(get('getOriginalTitle') or u''),
            'year': get('getYear') or 0,
            'imdb': to_text(get('getIMDBNumber') or u''),
            'show': to_text(get('getTVShowTitle') or u''),
            'season': get('getSeason'),
            'episode': get('getEpisode')}
    if not info['imdb']:
        info['imdb'] = to_text(get('getUniqueID', 'imdb') or u'')  # Kodi 20+
    return info


def set_subtitles(path):
    player = xbmc.Player()
    player.setSubtitles(to_kodi(path))
    player.showSubtitles(True)


def subtitle_streams():
    try:
        return [to_text(s) for s in xbmc.Player().getAvailableSubtitleStreams() if s]
    except RuntimeError:
        return []


# ---------------------------------------------------------------- files --
def translate_path(path):
    func = getattr(xbmcvfs, 'translatePath', None) or xbmc.translatePath  # 19+ / 17-18
    return to_text(func(to_kodi(path)))


def exists(path):
    return bool(xbmcvfs.exists(to_kodi(path)))


def mkdirs(path):
    return xbmcvfs.mkdirs(to_kodi(path))


def list_files(folder):
    if not folder.endswith(('/', '\\')):
        folder += '/'
    try:
        return [to_text(name) for name in xbmcvfs.listdir(to_kodi(folder))[1]]
    except Exception:  # pylint: disable=broad-except
        return []


def list_dirs(folder):
    if not folder.endswith(('/', '\\')):
        folder += '/'
    try:
        return [to_text(name) for name in xbmcvfs.listdir(to_kodi(folder))[0]]
    except Exception:  # pylint: disable=broad-except
        return []


def addon_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:  # pylint: disable=broad-except  # RuntimeError: not installed
        return False


def other_addon_setting(addon_id, setting_id):
    """A setting of another installed add-on ('' when it isn't installed)."""
    try:
        return to_text(xbmcaddon.Addon(addon_id).getSetting(setting_id)).strip()
    except Exception:  # pylint: disable=broad-except  # RuntimeError: not installed
        return u''


def mtime(path):
    try:
        return xbmcvfs.Stat(to_kodi(path)).st_mtime()
    except Exception:  # pylint: disable=broad-except
        return 0


def delete(path):
    return bool(xbmcvfs.delete(to_kodi(path)))


def set_setting(setting_id, value):
    addon().setSetting(setting_id, to_kodi(value))


def media_path(name):
    """Full path of a file in the add-on's resources/media folder."""
    return join(join(translate_path(addon_info('path')), 'resources'), 'media/' + name)


def copy(source, destination):
    return bool(xbmcvfs.copy(to_kodi(source), to_kodi(destination)))


def read_bytes(path):
    handle = xbmcvfs.File(to_kodi(path))
    try:
        if hasattr(handle, 'readBytes'):  # Kodi 18+
            return bytes(handle.readBytes())
        return handle.read()  # Kodi 17: a byte string on Python 2
    finally:
        handle.close()


def write_bytes(path, data):
    handle = xbmcvfs.File(to_kodi(path), 'w')
    try:
        return handle.write(data if PY2 else bytearray(data))
    finally:
        handle.close()


def profile_dir(*parts):
    path = translate_path(addon_info('profile'))
    for part in parts:
        path = join(path, part)
    if not path.endswith(('/', '\\')):
        path += '/'
    if not exists(path):
        mkdirs(path)
    return path


def local_ip():
    """Kodi's address on the home network, or None without a network."""
    ip = u''
    if hasattr(xbmc, 'getIPAddress'):
        ip = to_text(xbmc.getIPAddress() or u'')
    if not ip or ip in (u'127.0.0.1', u'0.0.0.0'):
        ip = to_text(xbmc.getInfoLabel('Network.IPAddress') or u'')
    return ip if ip and ip not in (u'127.0.0.1', u'0.0.0.0', u'Busy') else None


def ca_bundle():
    """Kodi ships a CA bundle on Android/Windows/macOS/iOS; Python on some of
    them can't find the system one, which breaks HTTPS."""
    path = translate_path('special://xbmc/system/certs/cacert.pem')
    return path if exists(path) else None


def is_stream(path):
    return (path or '').lower().startswith(STREAM_PREFIXES)


def unstack(path):
    """stack://a.avi , b.avi -> [a.avi, b.avi] (multi-part movies)."""
    if not (path or '').startswith('stack://'):
        return [path]
    return [part.replace(',,', ',').strip() for part in path[len('stack://'):].split(' , ')]


def video_folder(path):
    """Folder Kodi treats as 'next to the video'. For a video inside an archive
    (rar://<encoded archive path>/movie.mkv, also zip:// and archive://) that is
    the folder containing the archive, as in Kodi's subtitle download code."""
    for prefix in ('rar://', 'zip://', 'archive://'):
        if path.lower().startswith(prefix):
            archive = url_unquote(path[len(prefix):].split('/', 1)[0])
            return split(archive)[0]
    return split(path)[0]


def url_unquote(text):
    """'The%20Movie%20%C3%A9' -> u'The Movie \xe9' on Python 2 and 3."""
    if PY2:
        return unquote(to_kodi(text)).decode('utf-8', 'replace')
    return unquote(text)


def url_path(url):
    """Decoded path part of a web address: 'http://h:1/files/A%20B/c.mkv?x' -> '/files/A B/c.mkv'."""
    try:
        return url_unquote(urlsplit(url).path)
    except ValueError:
        return u''


def fetch_local(url, timeout=20, limit=5 * 1024 * 1024):
    """GET from a server on this device or the home network (bypassing any
    proxy): bytes, or None when it isn't there (404, refused, timeout)."""
    try:
        response = build_opener(ProxyHandler({})).open(to_kodi(url), timeout=timeout)
        try:
            data = response.read(limit + 1)
        finally:
            response.close()
    except Exception as error:  # pylint: disable=broad-except  # HTTPError 404, URLError, timeout
        if hasattr(error, 'close'):  # an HTTPError holds the open response
            error.close()
        return None
    return data if len(data) <= limit else None


def join(folder, name):
    windows = '\\' in folder and '://' not in folder
    return folder.rstrip('/\\') + ('\\' if windows else '/') + name


def split(path):
    cut = max(path.rfind('/'), path.rfind('\\'))
    return path[:cut + 1], path[cut + 1:]


def rpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    try:
        return json.loads(to_text(xbmc.executeJSONRPC(json.dumps(request)))).get('result')
    except (ValueError, TypeError, AttributeError):
        return None


# ------------------------------------------------------------ languages --
def target_language():
    """ISO 639-1 code; empty setting = Kodi's interface language."""
    code = setting('target_lang').lower()
    if not code:
        code = to_text(xbmc.getLanguage(xbmc.ISO_639_1)) or u'en'
    return code


def choosable_languages():
    """Languages offered in the 'translate into' dialog (setting, comma separated)."""
    return [c.strip().lower() for c in setting('languages').split(',') if c.strip()]


def base_language(code):
    """'sr-latn' -> 'sr'"""
    return code.lower().split('-')[0]


def script_of(code):
    """'sr-latn' -> 'latn', 'sr-cyrl' -> 'cyrl', 'sr' -> None"""
    parts = code.lower().split('-')
    return parts[1] if len(parts) > 1 and parts[1] in ('latn', 'cyrl') else None


def language_aliases(code):
    """All the ways a language shows up in file names and stream lists:
    'mk', 'mac', 'mkd', 'macedonian'."""
    code = base_language(code)
    names = set([code])
    for fmt in (xbmc.ISO_639_2, xbmc.ENGLISH_NAME):
        try:
            value = to_text(xbmc.convertLanguage(to_kodi(code), fmt))
        except Exception:  # pylint: disable=broad-except
            value = ''
        if value:
            names.add(value.lower())
    names |= set(BIBLIOGRAPHIC[n] for n in list(names) if n in BIBLIOGRAPHIC)
    return names


# ISO 639-2 has two codes for some languages; Kodi and file names use both.
BIBLIOGRAPHIC = {
    'mac': 'mkd', 'mkd': 'mac', 'alb': 'sqi', 'sqi': 'alb', 'ger': 'deu', 'deu': 'ger',
    'fre': 'fra', 'fra': 'fre', 'gre': 'ell', 'ell': 'gre', 'dut': 'nld', 'nld': 'dut',
    'cze': 'ces', 'ces': 'cze', 'slo': 'slk', 'slk': 'slo', 'rum': 'ron', 'ron': 'rum',
    'chi': 'zho', 'zho': 'chi', 'per': 'fas', 'fas': 'per', 'scc': 'srp', 'srp': 'scc',
    'scr': 'hrv', 'hrv': 'scr',
}
