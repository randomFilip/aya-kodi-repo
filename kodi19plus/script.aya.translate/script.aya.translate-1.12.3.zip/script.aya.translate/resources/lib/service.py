# -*- coding: utf-8 -*-
"""Automatic mode: runs in the background while Kodi is open.

* Watch downloads: a new .srt appears for the playing video (you used Kodi's
  subtitle search) -> translate it and load it.
* Auto on start: the video has no subtitle in your language but a foreign
  .srt exists -> translate it."""
import sys
import time

import xbmc

from . import core, finder, keys, kodiutils as ku
from .engines import language_name

POLL_SECONDS = 4
KEY_FILE_EVERY = 5  # look for a dropped aya-keys.txt every 5 polls (20 s)
START_DELAY_SECONDS = 8


class Service(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.video = None
        self.known = {}  # path -> modification time
        self.initial = []
        self.started = 0
        self.start_checked = True

    def run(self):
        log_environment()
        polls = 0
        while not self.waitForAbort(POLL_SECONDS):
            try:
                if polls % KEY_FILE_EVERY == 0:
                    keys.auto_import()
                polls += 1
                self.tick()
            except Exception as error:  # pylint: disable=broad-except
                ku.log(u'Service error: %r' % (error,), xbmc.LOGERROR)
        ku.log('Service stopped')

    def tick(self):
        video = ku.playing_video()
        if not video:
            self.video = None
            return
        auto = ku.setting_bool('auto_on_start')
        watch = ku.setting_bool('watch_downloads')
        if not (auto or watch):
            return
        target = ku.target_language()

        if video != self.video:  # new playback: remember what already exists
            self.video = video
            self.started = time.time()
            self.start_checked = not auto
            self.initial = finder.find(video, target, since=self.started)
            self.known = dict((c.path, c.mtime) for c in self.initial)
            ku.log(u'Playback started: %s' % video)
            ku.log(u'%d subtitle file(s) found%s' % (
                len(self.initial), u': ' + u', '.join(c.name for c in self.initial[:5])
                if self.initial else u''))
            return

        if not self.start_checked and time.time() - self.started >= START_DELAY_SECONDS:
            self.start_checked = True
            if not self.initial:
                self.explain_unreadable(target)
                return
            if self.has_subtitle_in(target):
                ku.log(u'Not translating: the movie already has a %s subtitle' % target)
                return
            self.offer(finder.best(self.initial), video, target)
            return

        if watch:
            candidates = finder.find(video, target, since=self.started)
            # new file, or Kodi overwrote an existing one (same language downloaded again)
            new = [c for c in candidates if c.mtime > self.known.get(c.path, -1)]
            self.known.update((c.path, c.mtime) for c in candidates)
            if new:
                ku.log(u'New subtitle file: %s' % new[0].path)
                self.offer(new[0], video, target)

    @classmethod
    def explain_unreadable(cls, target):
        """The player shows subtitles but there is no .srt file AYA can read
        (they're inside the video file or come from a stream): say so instead
        of staying silent."""
        streams = ku.subtitle_streams()
        if not streams or cls.has_subtitle_in(target):
            return
        ku.log(u'No subtitle file to translate. The player has subtitle tracks %s, but they are '
               u'inside the video or the stream, which AYA cannot read' % u', '.join(streams[:6]))
        ku.notify(ku.string(32181), 10000)

    @staticmethod
    def has_subtitle_in(target):
        aliases = ku.language_aliases(target)
        return any(s.lower() in aliases for s in ku.subtitle_streams())

    @staticmethod
    def offer(candidate, video, target):
        if ku.setting_bool('ask_language'):
            target = core.choose_language(candidate.name)
            if not target:
                ku.log(u'User chose not to translate %s' % candidate.name)
                return
        elif ku.setting_bool('confirm_auto'):
            question = ku.string(32066) % (candidate.name, language_name(target))
            if not ku.yesno(ku.addon_info('name'), question, 20000):
                return
        ku.log(u'Auto-translating %s into %s' % (candidate.path, target))
        core.run(candidate.path, video, background=True, target=target)


def log_environment():
    """Write the resolved folders to kodi.log, so users on any OS can find them."""
    ku.log(u'Service started: Kodi %s, Python %s' % (
        ku.to_text(xbmc.getInfoLabel('System.BuildVersion')), sys.version.split()[0]))
    for label, path in ((u'userdata', 'special://profile/'),
                        (u'add-on data', ku.addon_info('profile')),
                        (u'Kodi temp (downloaded subtitles)', 'special://temp/')):
        ku.log(u'%s: %s' % (label, ku.translate_path(path)))
    ku.log(u'custom subtitle folder: %s' % (finder.custom_subtitle_folder() or u'(not set)'))

